#ifndef SUBSTRATE_SHIM_H
#define SUBSTRATE_SHIM_H
#include <objc/runtime.h>
void MSHookMessageEx(Class _class, SEL sel, IMP imp, IMP *result);
#endif
