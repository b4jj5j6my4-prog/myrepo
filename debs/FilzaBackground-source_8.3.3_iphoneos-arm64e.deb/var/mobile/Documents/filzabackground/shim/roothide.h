#ifndef ROOTHIDE_SHIM_H
#define ROOTHIDE_SHIM_H
#import <Foundation/Foundation.h>
#import <dlfcn.h>
static inline NSString *jbroot(NSString *path) {
    static const char *(*fn)(const char *);
    static BOOL tried;
    if (!tried) { tried = YES; fn = (const char *(*)(const char *))dlsym(RTLD_DEFAULT, "jbroot"); }
    if (fn) { const char *r = fn(path.UTF8String); if (r && r[0]) return [NSString stringWithUTF8String:r]; }
    return path;
}
#endif
