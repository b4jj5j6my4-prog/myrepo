#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <PhotosUI/PhotosUI.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <sys/stat.h>
#import <CoreImage/CoreImage.h>
#include <roothide.h>
#include <substrate.h>
#include <stdint.h>

int __isPlatformVersionAtLeast(uint32_t platform, uint32_t major,
                               uint32_t minor, uint32_t patch) {
    if (platform != 2) return 1;
    NSOperatingSystemVersion v = { (NSInteger)major, (NSInteger)minor, (NSInteger)patch };
    return [[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:v] ? 1 : 0;
}

static NSString * const FBBundleID   = @"com.tigisoftware.Filza";
static NSString * const FBAlphaKey   = @"FBAlpha";
static NSString * const FBModeKey    = @"FBMode";
static NSString * const FBAccentKey  = @"FBAccent";
static NSString * const FBGlobalKey  = @"FBGlobalTint";
static NSString * const FBBlurKey    = @"FBBlur";
static NSString * const FBShadowKey  = @"FBShadow";
static NSString * const FBListPolishKey = @"FBListPolish";
static NSString * const FBHostNavKey    = @"FBHostNav";
static NSString * const FBHostBarKey    = @"FBHostBar";
static NSString * const FBHostBarYKey   = @"FBHostBarY";
static NSString * const FBHostBarYOnKey = @"FBHostBarYOn";
static NSString * const FBImageReadyName = @"FBImageReady";
static NSString * const FBNotifyName = @"FBBackgroundChanged";
static NSString * const FBVersion    = @"8.3.3";
static const NSInteger  kFBTag       = 0x46424731;

static const CGFloat kFBAlphaMin = 0.10;
static const CGFloat kFBAlphaMax = 0.60;
static const CGFloat kFBAlphaDef = 0.35;
static const CGFloat kFBBlurMin  = 0.0;
static const CGFloat kFBBlurMax  = 30.0;
static const CGFloat kFBBlurDef  = 0.0;

static inline CGFloat FBClamp(CGFloat v, CGFloat lo, CGFloat hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

#pragma mark - 主题色

static NSArray<NSString *> *FBPalette(void) {
    return @[ @"#0A84FF", @"#BF5AF2", @"#FF375F", @"#FF9F0A",
              @"#30D158", @"#64D2FF", @"#5E5CE6", @"#8E8E93" ];
}

static UIColor *FBColorFromHex(NSString *hex, CGFloat alpha) {
    if (hex.length < 7) return [UIColor systemBlueColor];
    unsigned rgb = 0;
    NSScanner *s = [NSScanner scannerWithString:[hex substringFromIndex:1]];
    if (![s scanHexInt:&rgb]) return [UIColor systemBlueColor];
    return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0
                           green:((rgb >> 8) & 0xFF) / 255.0
                            blue:(rgb & 0xFF) / 255.0
                           alpha:alpha];
}

static NSString *FBAccentHex(void) {
    NSString *h = [[NSUserDefaults standardUserDefaults] stringForKey:FBAccentKey];
    if (h.length >= 7) return h;
    return FBPalette().firstObject;
}

static UIColor *FBAccentColor(void) {
    return FBColorFromHex(FBAccentHex(), 1.0);
}

static BOOL FBGlobalTintOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBGlobalKey]) return YES;
    return [d boolForKey:FBGlobalKey];
}

static BOOL FBShadowOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBShadowKey]) return YES;
    return [d boolForKey:FBShadowKey];
}

#pragma mark - iOS 26 液态玻璃基础件

static const CGFloat kFBGlassRadius = 26.0;
static const CGFloat kFBCardInset   = 12.0;
static const CGFloat kFBRowHeight   = 58.0;
static const NSInteger kFBVTagTrailing = 0x46424743;

static BOOL FBIsDarkTrait(UITraitCollection *tc) {
    return tc.userInterfaceStyle == UIUserInterfaceStyleDark;
}

static UIColor *FBGlassTint(UITraitCollection *tc) {
    return FBIsDarkTrait(tc) ? [UIColor colorWithWhite:1.0 alpha:0.055]
                             : [UIColor colorWithWhite:1.0 alpha:0.28];
}

static UIColor *FBHairline(UITraitCollection *tc) {
    return FBIsDarkTrait(tc) ? [UIColor colorWithWhite:1.0 alpha:0.09]
                             : [UIColor colorWithWhite:0.0 alpha:0.07];
}

static UIBezierPath *FBRoundedPath(CGRect rect, CGFloat radius, UIRectCorner corners) {
    UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:rect
                                            byRoundingCorners:corners
                                                  cornerRadii:CGSizeMake(radius, radius)];
    return p;
}

@interface FBGlassCardView : UIView
@property (nonatomic, strong, readonly) UIView *clip;
@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UIView *tintView;
@property (nonatomic, strong) CAGradientLayer *sheen;
@property (nonatomic, strong) CAGradientLayer *stroke;
@property (nonatomic, strong) CAShapeLayer *strokeMask;
@property (nonatomic, assign) CGFloat radius;
@property (nonatomic, assign) UIRectCorner corners;
@property (nonatomic, assign) BOOL highlighted;
@property (nonatomic, strong) CAShapeLayer *maskLayer;
@property (nonatomic, strong) CAShapeLayer *contactShadow;
@end

@interface FBGlassCardView ()
@property (nonatomic, strong, readwrite) UIView *clip;
@end

@implementation FBGlassCardView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _radius = kFBGlassRadius;
    _corners = UIRectCornerAllCorners;
    self.backgroundColor = UIColor.clearColor;

    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOffset = CGSizeMake(0, 7);
    self.layer.shadowRadius = 11.0;
    self.layer.shadowOpacity = 0.0;

    _contactShadow = [CAShapeLayer layer];
    _contactShadow.fillColor = UIColor.clearColor.CGColor;
    _contactShadow.shadowColor = UIColor.blackColor.CGColor;
    _contactShadow.shadowOffset = CGSizeMake(0, 1.0);
    _contactShadow.shadowRadius = 2.0;
    _contactShadow.shadowOpacity = 0.0;
    [self.layer insertSublayer:_contactShadow atIndex:0];

    _clip = [[UIView alloc] initWithFrame:self.bounds];
    _clip.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _clip.backgroundColor = UIColor.clearColor;
    [self addSubview:_clip];

    _blurView = [[UIVisualEffectView alloc] initWithEffect:
                 [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThickMaterial]];
    _blurView.userInteractionEnabled = NO;
    [_clip addSubview:_blurView];

    _tintView = [[UIView alloc] initWithFrame:CGRectZero];
    _tintView.userInteractionEnabled = NO;
    [_clip addSubview:_tintView];

    _sheen = [CAGradientLayer layer];
    _sheen.colors = @[ (id)[UIColor colorWithWhite:1.0 alpha:0.22].CGColor,
                       (id)[UIColor colorWithWhite:1.0 alpha:0.05].CGColor,
                       (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor ];
    _sheen.locations = @[ @0.0, @0.32, @0.68 ];
    _sheen.startPoint = CGPointMake(0.05, 0.0);
    _sheen.endPoint = CGPointMake(0.85, 1.0);
    [_clip.layer addSublayer:_sheen];

    _stroke = [CAGradientLayer layer];
    _stroke.colors = @[ (id)[UIColor colorWithWhite:1.0 alpha:0.62].CGColor,
                        (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
                        (id)[UIColor colorWithWhite:1.0 alpha:0.42].CGColor ];
    _stroke.locations = @[ @0.0, @0.55, @1.0 ];
    _stroke.startPoint = CGPointMake(0.0, 0.0);
    _stroke.endPoint = CGPointMake(1.0, 1.0);
    _strokeMask = [CAShapeLayer layer];
    _strokeMask.fillColor = UIColor.clearColor.CGColor;
    _strokeMask.strokeColor = UIColor.blackColor.CGColor;
    _strokeMask.lineWidth = 1.0;
    _stroke.mask = _strokeMask;
    [_clip.layer addSublayer:_stroke];
    return self;
}

- (void)setCorners:(UIRectCorner)corners {
    _corners = corners;
    [self setNeedsLayout];
}

- (void)setHighlighted:(BOOL)highlighted {
    if (_highlighted == highlighted) return;
    _highlighted = highlighted;
    [UIView animateWithDuration:0.18 animations:^{
        UIColor *glass = FBGlassTint(self.traitCollection);
        self.tintView.backgroundColor = highlighted
            ? [glass colorWithAlphaComponent:MIN(1.0, CGColorGetAlpha(glass.CGColor) * 1.7)]
            : glass;
    }];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;

    UIBezierPath *shape = FBRoundedPath(b, self.radius, self.corners);
    if (!self.maskLayer) {
        self.maskLayer = [CAShapeLayer layer];
        self.clip.layer.mask = self.maskLayer;
    }
    self.maskLayer.frame = b;
    self.maskLayer.path = shape.CGPath;

    self.clip.frame = b;
    self.blurView.frame = self.clip.bounds;
    self.tintView.frame = self.clip.bounds;

    UIColor *glass = FBGlassTint(self.traitCollection);
    self.tintView.backgroundColor = self.highlighted
        ? [glass colorWithAlphaComponent:MIN(1.0, CGColorGetAlpha(glass.CGColor) * 1.7)]
        : glass;

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    self.sheen.frame = self.clip.bounds;
    self.stroke.frame = self.clip.bounds;
    UIBezierPath *line = FBRoundedPath(CGRectInset(self.clip.bounds, 0.5, 0.5),
                                       MAX(0.0, self.radius - 0.5), self.corners);
    self.strokeMask.path = line.CGPath;
    self.strokeMask.frame = self.clip.bounds;

    BOOL dark = FBIsDarkTrait(self.traitCollection);
    BOOL on = FBShadowOn();
    self.layer.shadowPath = shape.CGPath;
    self.layer.shadowOpacity = on ? (dark ? 0.22 : 0.075) : 0.0;
    self.contactShadow.frame = b;
    self.contactShadow.path = shape.CGPath;
    self.contactShadow.shadowPath = shape.CGPath;
    self.contactShadow.shadowOpacity = on ? (dark ? 0.16 : 0.05) : 0.0;
    [CATransaction commit];
}

- (void)traitCollectionDidChange:(UITraitCollection *)prev {
    [super traitCollectionDidChange:prev];
    [self setNeedsLayout];
}

@end

#pragma mark - 路径

static NSString *FBResolve(NSString *rel) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *jb = jbroot(rel);
    if (jb && [fm fileExistsAtPath:jb]) return jb;
    if ([fm fileExistsAtPath:rel]) return rel;
    return jb ?: rel;
}

static NSString *FBDir(void) {
    return FBResolve(@"/var/mobile/Library/Application Support/FilzaBackground");
}
static NSString *FBImage(void) {
    return FBResolve(@"/var/mobile/Library/Application Support/FilzaBackground/background.png");
}
static NSString *FBDarkImage(void) {
    return FBResolve(@"/var/mobile/Library/Application Support/FilzaBackground/background-dark.png");
}

static NSString *FBDisplayPath(NSString *abs) {
    NSRange r = [abs rangeOfString:@".jbroot-" options:NSCaseInsensitiveSearch];
    if (r.location == NSNotFound) return abs;
    NSUInteger end = NSMaxRange(r);
    while (end < abs.length) {
        unichar c = [abs characterAtIndex:end];
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) end++;
        else break;
    }
    if (end < abs.length && [abs characterAtIndex:end] == '/') end++;
    return [abs stringByReplacingCharactersInRange:NSMakeRange(r.location, end - r.location)
                                       withString:@"{越狱根}/"];
}

#pragma mark - 偏好

static CGFloat FBAlpha(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBAlphaKey]) return kFBAlphaDef;
    return FBClamp([d doubleForKey:FBAlphaKey], kFBAlphaMin, kFBAlphaMax);
}

static void FBSetAlpha(CGFloat v) {
    [[NSUserDefaults standardUserDefaults] setDouble:FBClamp(v, kFBAlphaMin, kFBAlphaMax)
                                              forKey:FBAlphaKey];
}

static CGFloat FBBlur(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBBlurKey]) return kFBBlurDef;
    return FBClamp([d doubleForKey:FBBlurKey], kFBBlurMin, kFBBlurMax);
}

static void FBSetBlur(CGFloat v) {
    [[NSUserDefaults standardUserDefaults] setDouble:FBClamp(v, kFBBlurMin, kFBBlurMax)
                                              forKey:FBBlurKey];
}

static NSString *FBBlurText(void) {
    CGFloat b = FBBlur();
    return b <= 0.5 ? @"关" : [NSString stringWithFormat:@"%.0f", b];
}

static NSInteger FBMode(void) {
    NSInteger m = [[NSUserDefaults standardUserDefaults] integerForKey:FBModeKey];
    return MAX(0, MIN(2, m));
}

static NSString *FBModeName(NSInteger mode) {
    static NSArray *names = nil;
    if (!names) names = @[ @"填充", @"适应", @"拉伸" ];
    return names[(NSUInteger)MAX(0, MIN(2, mode))];
}

static UIViewContentMode FBContentModeForMode(NSInteger mode) {
    switch (mode) {
        case 0:  return UIViewContentModeScaleAspectFill;
        case 1:  return UIViewContentModeScaleAspectFit;
        default: return UIViewContentModeScaleToFill;
    }
}

static BOOL FBInFilza(void) {
    return [NSBundle.mainBundle.bundleIdentifier isEqualToString:FBBundleID];
}

static BOOL FBDarkMode(void) {
    UIWindow *win = nil;
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.isKeyWindow) { win = w; break; }
    }
    if (!win) win = UIApplication.sharedApplication.windows.firstObject;
    if (win) return win.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
    return UITraitCollection.currentTraitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
}

static BOOL FBHasDarkImage(void) {
    return [[NSFileManager defaultManager] fileExistsAtPath:FBDarkImage()];
}

static NSString *FBCurrentPath(void) {
    if (FBDarkMode() && FBHasDarkImage()) return FBDarkImage();
    return FBImage();
}

#pragma mark - 前置声明

static void FBEnsureDir(void);
static BOOL FBWriteImage(UIImage *image, NSString *path);
static UIImage *FBCompressImage(UIImage *image);

#pragma mark - 图片缓存（路径 + mtime 变化才重新解码）

static UIImage *gFBImageCache = nil;
static NSString *gFBImageCacheKey = nil;

static CGFloat FBFileMTime(NSString *path) {
    NSDictionary *attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
    return attrs ? [attrs fileModificationDate].timeIntervalSince1970 : 0;
}

static void FBInvalidateImageCache(void) {
    gFBImageCache = nil;
    gFBImageCacheKey = nil;
}

static CIContext *FBSharedCIContext(void) {
    static CIContext *ctx = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ctx = [CIContext contextWithOptions:nil];
    });
    return ctx;
}

static UIImage *FBLoadScaled(NSString *path, CGFloat maxSide) {
    if (path.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:path]) return nil;

    UIImage *img = [UIImage imageWithContentsOfFile:path];
    if (!img) return nil;

    CGFloat w = img.size.width, h = img.size.height;
    if (w <= 0 || h <= 0) return img;

    CGFloat side = MAX(w, h);
    if (side <= maxSide || maxSide <= 0) return img;

    CGFloat s = maxSide / side;
    CGSize newSize = CGSizeMake(floor(w * s), floor(h * s));
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 1.0);
    [img drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *scaled = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaled ?: img;
}

static UIImage *FBBlurred(UIImage *img, CGFloat radius) {
    if (!img || radius <= 0.5) return img;
    CGImageRef cg = img.CGImage;
    if (!cg) return img;

    CIImage *ci = [CIImage imageWithCGImage:cg];
    if (!ci) return img;

    CGRect ext = ci.extent;

    CIFilter *clamp = [CIFilter filterWithName:@"CIAffineClamp"];
    if (clamp) {
        [clamp setValue:ci forKey:kCIInputImageKey];
        [clamp setValue:[NSValue valueWithCGAffineTransform:CGAffineTransformIdentity]
                 forKey:@"inputTransform"];
        CIImage *clamped = clamp.outputImage;
        if (clamped) ci = clamped;
    }

    CIFilter *f = [CIFilter filterWithName:@"CIGaussianBlur"];
    if (!f) return img;
    [f setValue:ci forKey:kCIInputImageKey];
    [f setValue:@(radius) forKey:kCIInputRadiusKey];

    CIImage *out = f.outputImage;
    if (!out) return img;

    out = [out imageByCroppingToRect:ext];

    CGImageRef blurred = [FBSharedCIContext() createCGImage:out fromRect:ext];
    if (!blurred) return img;

    UIImage *result = [UIImage imageWithCGImage:blurred
                                          scale:img.scale
                                     orientation:img.imageOrientation];
    CGImageRelease(blurred);
    return result ?: img;
}

static NSString *FBImageCacheKey(NSString *path, CGFloat maxSide, CGFloat radius) {
    return [NSString stringWithFormat:@"%@|%.0f|%.0f|%.1f",
            path, FBFileMTime(path), maxSide, radius];
}

static CGFloat FBScreenMaxSide(void) {
    CGSize screen = UIScreen.mainScreen.bounds.size;
    CGFloat scale = UIScreen.mainScreen.scale > 0 ? UIScreen.mainScreen.scale : 2.0;
    CGFloat maxSide = MAX(screen.width, screen.height) * scale;
    return maxSide > 0 ? maxSide : 2688.0;
}

static UIImage *FBScaledImage(void) {
    NSString *path = FBCurrentPath();
    if (path.length == 0) return nil;

    CGFloat maxSide = FBScreenMaxSide();
    CGFloat radius = FBBlur();
    NSString *key = FBImageCacheKey(path, maxSide, radius);

    if (gFBImageCache && gFBImageCacheKey && [gFBImageCacheKey isEqualToString:key]) {
        return gFBImageCache;
    }

    UIImage *base = FBLoadScaled(path, maxSide);
    if (!base) return nil;

    UIImage *result = FBBlurred(base, radius);
    gFBImageCache = result;
    gFBImageCacheKey = key;
    return result;
}

#pragma mark - 背景层注册表

static NSHashTable<UIView *> *gFBContainers = nil;

static NSHashTable<UIView *> *FBRegistry(void) {
    if (!gFBContainers) gFBContainers = [NSHashTable weakObjectsHashTable];
    return gFBContainers;
}

static void FBRegisterContainer(UIView *v) { if (v) [FBRegistry() addObject:v]; }
static void FBUnregisterContainer(UIView *v) { if (v) [FBRegistry() removeObject:v]; }

static UIView *FBExistingBackground(UIView *view) {
    if (!view) return nil;
    for (UIView *sub in view.subviews) {
        if (sub.tag == kFBTag) return sub;
    }
    UIView *host = view.superview;
    if (host) {
        for (UIView *sub in host.subviews) {
            if (sub.tag == kFBTag) return sub;
        }
    }
    return nil;
}

#pragma mark - 判定

static BOOL FBViewIsViewer(UIView *v) {
    for (UIResponder *r = v; r; r = r.nextResponder) {
        if ([r isKindOfClass:[UIViewController class]]) {
            NSString *cn = [NSStringFromClass([r class]) lowercaseString] ?: @"";
            NSArray *keys = @[ @"viewer", @"editor", @"textedit", @"preview",
                               @"terminal", @"player", @"hex", @"inspector" ];
            for (NSString *k in keys) if ([cn containsString:k]) return YES;
            return NO;
        }
    }
    return NO;
}

static BOOL FBIsFilzaController(UIViewController *vc) {
    if (!vc) return NO;
    NSString *cn = NSStringFromClass([vc class]) ?: @"";
    if (cn.length == 0) return NO;

    if ([cn isEqualToString:@"FBSettingsController"]) return NO;
    if ([cn isEqualToString:@"FBImagePickerHostController"]) return NO;

    NSString *low = cn.lowercaseString;
    if ([low containsString:@"action"] || [low containsString:@"alert"] ||
        [low containsString:@"picker"]) return NO;

    if ([cn hasPrefix:@"TG"]) return YES;
    if ([cn hasPrefix:@"Fila"]) return YES;
    if ([cn hasPrefix:@"Filza"]) return YES;

    NSBundle *b = [NSBundle bundleForClass:[vc class]];
    if ([[b bundleIdentifier] isEqualToString:FBBundleID]) return YES;

    return NO;
}

#pragma mark - 列表美化（隐藏滚动条 + 底部留白）

static char kFBInsetBaseKey;
static NSString * const FBListPadKey = @"FBListPad";
static const CGFloat kFBListPadMin = 0.0;
static const CGFloat kFBListPadMax = 60.0;
static const CGFloat kFBListPadDef = 24.0;

static CGFloat FBListPad(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBListPadKey]) return kFBListPadDef;
    return FBClamp([d doubleForKey:FBListPadKey], kFBListPadMin, kFBListPadMax);
}

static void FBSetListPad(CGFloat v) {
    [[NSUserDefaults standardUserDefaults] setDouble:FBClamp(v, kFBListPadMin, kFBListPadMax)
                                              forKey:FBListPadKey];
}

static BOOL FBListPolishOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBListPolishKey]) return YES;
    return [d boolForKey:FBListPolishKey];
}

static void FBFindList(UIView *v, int depth, UIView **out) {
    if (!v || depth > 6 || *out) return;
    if ([v isKindOfClass:[UITableView class]] || [v isKindOfClass:[UICollectionView class]]) {
        *out = v;
        return;
    }
    for (UIView *sub in v.subviews) FBFindList(sub, depth + 1, out);
}

static void FBPolishListScroll(UIScrollView *sv, BOOL on) {
    if (!sv) return;
    sv.showsVerticalScrollIndicator = !on;
    sv.showsHorizontalScrollIndicator = !on;

    NSNumber *baseNum = objc_getAssociatedObject(sv, &kFBInsetBaseKey);
    UIEdgeInsets inset = sv.contentInset;
    if (on) {
        if (!baseNum) {
            baseNum = @(inset.bottom);
            objc_setAssociatedObject(sv, &kFBInsetBaseKey, baseNum, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        CGFloat target = baseNum.doubleValue + FBListPad();
        if (fabs(inset.bottom - target) > 0.5) {
            inset.bottom = target;
            sv.contentInset = inset;
        }
    } else if (baseNum && fabs(inset.bottom - baseNum.doubleValue) > 0.5) {
        inset.bottom = baseNum.doubleValue;
        sv.contentInset = inset;
    }
}

static void FBStripToolbarBackground(UIToolbar *bar, BOOL on);
static void FBApplyListPolish(UIViewController *vc);
static void FBCollectVCs(UIViewController *vc, NSMutableArray<UIViewController *> *out);
static BOOL FBIsSystemOverlayWindow(UIWindow *w);
static BOOL FBHostBarGlassOn(void);
static BOOL FBHostNavGlassOn(void);

static void FBApplyListPolishToAll(void) {
    NSMutableArray<UIViewController *> *vcs = [NSMutableArray array];
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.hidden || w.alpha <= 0.01) continue;
        if (FBIsSystemOverlayWindow(w)) continue;
        UIViewController *root = w.rootViewController;
        if (!root) continue;
        [vcs addObject:root];
        FBCollectVCs(root, vcs);
    }
    for (UIViewController *vc in vcs) {
        if (!FBIsFilzaController(vc)) continue;
        FBApplyListPolish(vc);
    }
}

static char kFBLiftBaseKey;

static void FBExtendListUnderBar(UIScrollView *sv, BOOL on) {
    if (!sv) return;
    NSArray *base = objc_getAssociatedObject(sv, &kFBLiftBaseKey);
    if (!base) {
        base = @[ [NSValue valueWithUIEdgeInsets:sv.contentInset],
                  @(sv.contentInsetAdjustmentBehavior) ];
        objc_setAssociatedObject(sv, &kFBLiftBaseKey, base, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    UIEdgeInsets orig = [(NSValue *)base[0] UIEdgeInsetsValue];
    UIScrollViewContentInsetAdjustmentBehavior beh =
        (UIScrollViewContentInsetAdjustmentBehavior)[(NSNumber *)base[1] integerValue];

    if (!on) {
        sv.contentInsetAdjustmentBehavior = beh;
        sv.contentInset = orig;
        sv.scrollIndicatorInsets = orig;
        return;
    }

    CGFloat top = sv.adjustedContentInset.top;
    sv.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    UIEdgeInsets in = sv.contentInset;
    in.top = top;
    in.bottom = 0;
    sv.contentInset = in;

    UIEdgeInsets ind = sv.scrollIndicatorInsets;
    ind.top = top;
    ind.bottom = 0;
    sv.scrollIndicatorInsets = ind;
}

static void FBApplyListPolish(UIViewController *vc) {
    if (!vc || !vc.isViewLoaded) return;
    NSString *cnv = NSStringFromClass([vc class]) ?: @"";
    if ([cnv containsString:@"Safari"] || [cnv containsString:@"Web"]) return;
    if (FBViewIsViewer(vc.view)) return;
    UIView *listView = nil;
    FBFindList(vc.view, 0, &listView);
    if (!listView) return;

    UIScrollView *sv = (UIScrollView *)listView;
    FBPolishListScroll(sv, FBListPolishOn());
    FBExtendListUnderBar(sv, FBHostBarGlassOn());
}

#pragma mark - 主页导航栏

static NSMapTable<UINavigationBar *, UINavigationBarAppearance *> *gFBOrigNavApp = nil;

static BOOL FBHostNavGlassOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBHostNavKey]) return YES;
    return [d boolForKey:FBHostNavKey];
}

static void FBApplyHostNavBar(UINavigationBar *bar) {
    if (!bar) return;
    if (!gFBOrigNavApp) gFBOrigNavApp = [NSMapTable weakToStrongObjectsMapTable];

    UINavigationBarAppearance *orig = [gFBOrigNavApp objectForKey:bar];
    if (!orig) {
        orig = bar.standardAppearance;
        if (orig) [gFBOrigNavApp setObject:orig forKey:bar];
    }

    if (!FBHostNavGlassOn()) {
        if (orig) {
            bar.standardAppearance = orig;
            bar.scrollEdgeAppearance = orig;
            if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = orig;
        }
        return;
    }

    UIColor *fbWant = [UIColor.systemBackgroundColor colorWithAlphaComponent:0.42];
    if ([bar.standardAppearance.backgroundColor isEqual:fbWant]) return;

    UINavigationBarAppearance *ap = [[UINavigationBarAppearance alloc] init];
    [ap configureWithDefaultBackground];
    ap.backgroundColor = fbWant;
    ap.shadowColor = UIColor.clearColor;
    ap.titleTextAttributes = @{ NSForegroundColorAttributeName: UIColor.labelColor };
    if ([bar.standardAppearance isEqual:ap] && [bar.scrollEdgeAppearance isEqual:ap]) return;

    bar.standardAppearance = ap;
    bar.scrollEdgeAppearance = ap;
    if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = ap;
}

#pragma mark 底部工具栏

static NSMapTable<UIToolbar *, UIToolbarAppearance *> *gFBOrigBarApp = nil;

static BOOL FBHostBarOffsetOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBHostBarYOnKey]) return YES;
    return [d boolForKey:FBHostBarYOnKey];
}

static CGFloat FBHostBarOffset(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBHostBarYKey]) return 0.0;
    return FBClamp([d doubleForKey:FBHostBarYKey], 0.0, 30.0);
}

static void FBSetHostBarOffset(CGFloat v) {
    [[NSUserDefaults standardUserDefaults] setDouble:FBClamp(v, 0.0, 30.0) forKey:FBHostBarYKey];
}

static BOOL FBHostBarGlassOn(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if (![d objectForKey:FBHostBarKey]) return YES;
    return [d boolForKey:FBHostBarKey];
}

static void FBFindToolbar(UIView *v, int depth, UIToolbar **out) {
    if (!v || depth > 5 || *out) return;
    if ([v isKindOfClass:[UIToolbar class]]) { *out = (UIToolbar *)v; return; }
    for (UIView *sub in v.subviews) FBFindToolbar(sub, depth + 1, out);
}

static void FBCollectToolbars(UIView *v, int depth, NSMutableArray<UIToolbar *> *out) {
    if (!v || depth > 8 || out.count > 6) return;
    if ([v isKindOfClass:[UIToolbar class]]) {
        [out addObject:(UIToolbar *)v];
        return;
    }
    for (UIView *sub in v.subviews) FBCollectToolbars(sub, depth + 1, out);
}

static void FBStripToolbarBackground(UIToolbar *bar, BOOL on) {
    if (!bar) return;
    for (UIView *sub in bar.subviews) {
        NSString *cn = NSStringFromClass([sub class]) ?: @"";
        if (![cn containsString:@"BarBackground"]) continue;
        if (on) sub.backgroundColor = UIColor.clearColor;
        for (UIView *iv in sub.subviews) {
            if ([iv isKindOfClass:[UIImageView class]]) iv.hidden = on;
        }
    }
    if (on) {
        [bar setNeedsLayout];
        [bar layoutIfNeeded];
    }
}

static BOOL FBHasVisibleBarBackground(UIToolbar *bar) {
    for (UIView *sub in bar.subviews) {
        NSString *cn = NSStringFromClass([sub class]) ?: @"";
        if (![cn containsString:@"BarBackground"]) continue;
        for (UIView *iv in sub.subviews) {
            if ([iv isKindOfClass:[UIImageView class]] && !iv.hidden) return YES;
        }
    }
    return NO;
}

static void FBApplyHostToolbar(UIToolbar *bar) {
    if (!bar) return;
    if (!gFBOrigBarApp) gFBOrigBarApp = [NSMapTable weakToStrongObjectsMapTable];

    UIToolbarAppearance *orig = [gFBOrigBarApp objectForKey:bar];
    if (!orig) {
        orig = bar.standardAppearance;
        if (orig) [gFBOrigBarApp setObject:orig forKey:bar];
    }

    if (!FBHostBarGlassOn()) {
        if (!CGAffineTransformIsIdentity(bar.transform)) bar.transform = CGAffineTransformIdentity;
        if (orig) {
            bar.standardAppearance = orig;
            bar.scrollEdgeAppearance = orig;
            if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = orig;
        }
        FBStripToolbarBackground(bar, NO);
        return;
    }

    CGFloat fbOff = FBHostBarOffsetOn() ? FBHostBarOffset() : 0.0;
    CGAffineTransform fbTf = fbOff > 0.01 ? CGAffineTransformMakeTranslation(0, fbOff)
                                          : CGAffineTransformIdentity;
    if ([bar.standardAppearance.backgroundColor isEqual:UIColor.clearColor] &&
        [bar.standardAppearance.shadowColor isEqual:UIColor.clearColor] &&
        CGAffineTransformEqualToTransform(bar.transform, fbTf) &&
        !FBHasVisibleBarBackground(bar)) return;

    [bar setBackgroundImage:[UIImage new] forToolbarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [bar setBackgroundImage:[UIImage new] forToolbarPosition:UIBarPositionAny barMetrics:UIBarMetricsCompact];
    [bar setShadowImage:[UIImage new] forToolbarPosition:UIBarPositionAny];

    bar.translucent = YES;
    bar.barTintColor = nil;
    bar.backgroundColor = UIColor.clearColor;

    UIToolbarAppearance *ap = [[UIToolbarAppearance alloc] init];

    [ap configureWithTransparentBackground];
    ap.backgroundEffect = nil;
    ap.backgroundColor = UIColor.clearColor;
    ap.shadowColor = UIColor.clearColor;
    bar.standardAppearance = ap;
    bar.scrollEdgeAppearance = ap;
    if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = ap;

    FBStripToolbarBackground(bar, YES);

    if (!CGAffineTransformEqualToTransform(bar.transform, fbTf)) bar.transform = fbTf;
}

static UIToolbar *FBFindToolbarForVC(UIViewController *vc) {
    if (!vc) return nil;
    UIToolbar *tb = nil;
    if (vc.isViewLoaded) FBFindToolbar(vc.view, 0, &tb);
    if (!tb && vc.navigationController) FBFindToolbar(vc.navigationController.view, 0, &tb);
    if (!tb && vc.tabBarController) FBFindToolbar(vc.tabBarController.view, 0, &tb);
    if (!tb) {
        for (UIWindow *w in UIApplication.sharedApplication.windows) {
            if (!w || w.hidden) continue;
            FBFindToolbar(w, 0, &tb);
            if (tb) break;
        }
    }
    return tb;
}

static void (*orig_setToolbarBg)(UIToolbar *, SEL, UIImage *, UIBarPosition, UIBarMetrics);
static void fb_setToolbarBg(UIToolbar *self, SEL _cmd, UIImage *image, UIBarPosition pos, UIBarMetrics metrics) {
    if (FBHostBarGlassOn()) image = [UIImage new];
    orig_setToolbarBg(self, _cmd, image, pos, metrics);
}

static void (*orig_setToolbarShadow)(UIToolbar *, SEL, UIImage *, UIBarPosition);
static void fb_setToolbarShadow(UIToolbar *self, SEL _cmd, UIImage *image, UIBarPosition pos) {
    if (FBHostBarGlassOn()) image = [UIImage new];
    orig_setToolbarShadow(self, _cmd, image, pos);
}

static void FBApplyHostToolbarToAll(void) {
    NSMutableArray<UIViewController *> *vcs = [NSMutableArray array];
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.hidden || w.alpha <= 0.01) continue;
        if (FBIsSystemOverlayWindow(w)) continue;
        UIViewController *root = w.rootViewController;
        if (!root) continue;
        [vcs addObject:root];
        FBCollectVCs(root, vcs);
    }
    for (UIViewController *vc in vcs) {
        if (!FBIsFilzaController(vc) || !vc.isViewLoaded) continue;
        NSMutableArray<UIToolbar *> *bars = [NSMutableArray array];
        if (vc.isViewLoaded) FBCollectToolbars(vc.view, 0, bars);
        for (UIWindow *w in UIApplication.sharedApplication.windows) FBCollectToolbars(w, 0, bars);
        for (UIToolbar *b in bars) FBApplyHostToolbar(b);
    }
}

static void FBApplyHostNavToAll(void) {
    NSMutableArray<UIViewController *> *vcs = [NSMutableArray array];
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.hidden || w.alpha <= 0.01) continue;
        if (FBIsSystemOverlayWindow(w)) continue;
        UIViewController *root = w.rootViewController;
        if (!root) continue;
        [vcs addObject:root];
        FBCollectVCs(root, vcs);
    }
    for (UIViewController *vc in vcs) {
        if (!FBIsFilzaController(vc)) continue;
        FBApplyHostNavBar(vc.navigationController.navigationBar);
    }
}

#pragma mark - 背景层

static void FBApplyAlphaToView(UIView *v, CGFloat a) {
    if (!v) return;
    if (v.alpha != a) v.alpha = a;
}

static void FBApplyAlphaToAll(void) {
    CGFloat a = FBAlpha();
    for (UIView *v in FBRegistry().allObjects) {
        if (!v.window) continue;
        FBApplyAlphaToView(v, a);
    }
}

static void FBAddBackgroundToView(UIView *view) {
    if (!view || ![NSThread isMainThread]) return;
    if (FBViewIsViewer(view)) return;

    UIImage *image = FBScaledImage();
    UIView *existing = FBExistingBackground(view);

    if (!image) {
        if (existing) { FBUnregisterContainer(existing); [existing removeFromSuperview]; }
        return;
    }

    UIViewContentMode mode = FBContentModeForMode(FBMode());
    CGFloat alpha = FBAlpha();

    UIView *hostView = ([view isKindOfClass:[UIScrollView class]] ? view.superview : view) ?: view;
    if (existing) {
        if (!CGRectEqualToRect(existing.frame, hostView.bounds)) existing.frame = hostView.bounds;
        FBApplyAlphaToView(existing, alpha);
        for (UIView *sub in existing.subviews) {
            if (![sub isKindOfClass:[UIImageView class]]) continue;
            UIImageView *iv = (UIImageView *)sub;
            if (iv.image != image) iv.image = image;
            if (iv.contentMode != mode) iv.contentMode = mode;
            if (!CGRectEqualToRect(iv.frame, existing.bounds)) iv.frame = existing.bounds;
        }
        return;
    }

    UIView *container = [[UIView alloc] initWithFrame:view.bounds];
    container.tag = kFBTag;
    container.userInteractionEnabled = NO;
    container.clipsToBounds = YES;
    container.backgroundColor = UIColor.clearColor;
    container.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    container.alpha = alpha;

    UIImageView *iv = [[UIImageView alloc] initWithFrame:container.bounds];
    iv.image = image;
    iv.contentMode = mode;
    iv.clipsToBounds = YES;
    iv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [container addSubview:iv];

    UIView *host = ([view isKindOfClass:[UIScrollView class]] ? view.superview : view);
    if (!host) host = view;
    container.frame = host.bounds;
    [host insertSubview:container atIndex:0];
    FBRegisterContainer(container);
}

static void FBApplyImageToAll(UIImage *img) {
    if (!img) return;
    for (UIView *container in FBRegistry().allObjects) {
        if (!container.window) continue;
        for (UIView *sub in container.subviews) {
            if ([sub isKindOfClass:[UIImageView class]]) ((UIImageView *)sub).image = img;
        }
    }
}

static NSUInteger gFBRebuildGen = 0;

static void FBRequestImageRebuild(void) {
    gFBRebuildGen++;
    NSUInteger gen = gFBRebuildGen;

    NSString *path = FBCurrentPath();
    CGFloat radius = FBBlur();
    CGFloat maxSide = FBScreenMaxSide();
    NSString *key = FBImageCacheKey(path, maxSide, radius);

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        UIImage *base = FBLoadScaled(path, maxSide);
        UIImage *img = base ? FBBlurred(base, radius) : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (gen != gFBRebuildGen) return;
            if (!img) return;
            gFBImageCache = img;
            gFBImageCacheKey = key;
            FBApplyImageToAll(img);
            [[NSNotificationCenter defaultCenter] postNotificationName:FBImageReadyName object:nil];
        });
    });
}

#pragma mark - 全局强调色

static BOOL FBIsSystemOverlayWindow(UIWindow *w) {
    if (!w) return YES;
    NSString *cn = NSStringFromClass([w class]) ?: @"";

    if ([cn containsString:@"Alert"] || [cn containsString:@"Keyboard"] ||
        [cn containsString:@"StatusBar"] || [cn containsString:@"PassThrough"] ||
        [cn containsString:@"Popover"] || [cn containsString:@"Platter"] ||
        [cn containsString:@"TextEffects"] || [cn containsString:@"Presentation"]) {
        return YES;
    }
    if (w.windowLevel >= UIWindowLevelAlert) return YES;

    UIViewController *root = w.rootViewController;
    if (root) {
        if ([root isKindOfClass:[UIImagePickerController class]]) return YES;
        if ([root isKindOfClass:[UIDocumentPickerViewController class]]) return YES;
        if (@available(iOS 14.0, *)) {
            if ([root isKindOfClass:[PHPickerViewController class]]) return YES;
        }
        if ([root isKindOfClass:[UIAlertController class]]) return YES;
        if ([root isKindOfClass:[UIActivityViewController class]]) return YES;
    }
    return NO;
}

static void FBApplyGlobalTint(void) {
    if (!FBInFilza() || !FBGlobalTintOn()) return;
    UIColor *c = FBAccentColor();
    if (!c) return;

    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (!w || w.hidden) continue;
        if (FBIsSystemOverlayWindow(w)) continue;
        if (![w.tintColor isEqual:c]) w.tintColor = c;
    }
}

#pragma mark - 刷新

static BOOL FBHasModalPresented(void) {
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.hidden || w.alpha <= 0.01) continue;
        UIViewController *root = w.rootViewController;
        if (!root) continue;
        if ([root isKindOfClass:[UIAlertController class]] ||
            [root isKindOfClass:[UIImagePickerController class]] ||
            [root isKindOfClass:[UIDocumentPickerViewController class]] ||
            [root isKindOfClass:[UIActivityViewController class]]) {
            return YES;
        }
        if (@available(iOS 14.0, *)) {
            if ([root isKindOfClass:[PHPickerViewController class]]) return YES;
        }
    }
    return NO;
}

static void FBCollectVCs(UIViewController *vc, NSMutableArray<UIViewController *> *out) {
    if (!vc || !out) return;
    for (UIViewController *child in vc.childViewControllers) {
        [out addObject:child];
        FBCollectVCs(child, out);
    }
    if (vc.presentedViewController) {
        [out addObject:vc.presentedViewController];
        FBCollectVCs(vc.presentedViewController, out);
    }
}

static void FBRefreshAllWindows(void);

static void FBRefreshAllWindows(void) {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ FBRefreshAllWindows(); });
        return;
    }

    static BOOL busy = NO;
    if (busy) return;
    busy = YES;

    if (FBHasModalPresented()) {
        busy = NO;
        static NSTimeInterval lastRetry = 0;
        NSTimeInterval now = [NSDate date].timeIntervalSince1970;
        if (now - lastRetry > 0.4) {
            lastRetry = now;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{ FBRefreshAllWindows(); });
        }
        return;
    }

    NSMutableArray<UIViewController *> *vcs = [NSMutableArray array];
    for (UIWindow *w in UIApplication.sharedApplication.windows) {
        if (w.hidden || w.alpha <= 0.01) continue;
        if (FBIsSystemOverlayWindow(w)) continue;
        UIViewController *root = w.rootViewController;
        if (!root) continue;
        [vcs addObject:root];
        FBCollectVCs(root, vcs);
    }

    for (UIViewController *vc in vcs) {
        if (!FBIsFilzaController(vc)) continue;
        if (!vc.isViewLoaded) continue;
        FBAddBackgroundToView(vc.view);
    }

    FBApplyGlobalTint();
    busy = NO;
}

static void FBNotifyChanged(void) {
    [[NSNotificationCenter defaultCenter] postNotificationName:FBNotifyName object:nil];
    FBInvalidateImageCache();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ FBRefreshAllWindows(); });
}

#pragma mark - 监听

static void FBInstallObservers(void) {
    static BOOL installed = NO;
    if (installed) return;
    installed = YES;

    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];

    [nc addObserverForName:FBNotifyName object:nil queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) { FBRefreshAllWindows(); }];

    [nc addObserverForName:UIApplicationDidBecomeActiveNotification object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) {
        FBInvalidateImageCache();
        FBApplyGlobalTint();
        FBRefreshAllWindows();
    }];

    [nc addObserverForName:UIAccessibilityDarkerSystemColorsStatusDidChangeNotification
                    object:nil queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) {
        FBInvalidateImageCache();
        FBRefreshAllWindows();
    }];

    [nc addObserverForName:UIDeviceOrientationDidChangeNotification object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) {
        static NSTimeInterval last = 0;
        NSTimeInterval now = [NSDate date].timeIntervalSince1970;
        if (now - last < 0.5) return;
        last = now;
        FBRefreshAllWindows();
    }];

    [nc addObserverForName:UIWindowDidBecomeKeyNotification object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) {
        static NSTimeInterval last = 0;
        NSTimeInterval now = [NSDate date].timeIntervalSince1970;
        if (now - last < 1.0) return;
        last = now;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            FBApplyGlobalTint();
            FBRefreshAllWindows();
        });
    }];
}

#pragma mark - 选图 Host

typedef NS_ENUM(NSInteger, FBPickSource) {
    FBPickSourcePhotos,
    FBPickSourceFiles
};

@interface FBImagePickerHostController : UIViewController <PHPickerViewControllerDelegate, UIDocumentPickerDelegate>
@property (nonatomic, copy) void (^completionBlock)(UIImage *image);
- (void)presentFrom:(UIViewController *)host source:(FBPickSource)source;
@end

@implementation FBImagePickerHostController

- (void)presentFrom:(UIViewController *)host source:(FBPickSource)source {
    if (source == FBPickSourcePhotos) {
        if (@available(iOS 14.0, *)) {
            PHPickerConfiguration *config = [[PHPickerConfiguration alloc] init];
            config.selectionLimit = 1;
            config.filter = [PHPickerFilter imagesFilter];
            PHPickerViewController *picker = [[PHPickerViewController alloc] initWithConfiguration:config];
            picker.delegate = self;
            [host presentViewController:picker animated:YES completion:nil];
        } else {
            [self finishWithImage:nil];
        }
        return;
    }

    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *png  = [UTType typeWithIdentifier:@"public.png"];
    UTType *jpeg = [UTType typeWithIdentifier:@"public.jpeg"];
    if (png)  [types addObject:png];
    if (jpeg) [types addObject:jpeg];
    if (types.count == 0) [types addObject:UTTypeImage];

    UIDocumentPickerViewController *picker =
        [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self;
    picker.allowsMultipleSelection = NO;
    [host presentViewController:picker animated:YES completion:nil];
}

- (void)finishWithImage:(UIImage *)image dismiss:(UIViewController *)picker {
    void (^block)(UIImage *) = self.completionBlock;
    self.completionBlock = nil;
    void (^fire)(void) = ^{ if (block) block(image); };
    if (picker && picker.presentingViewController) {
        [picker dismissViewControllerAnimated:YES completion:fire];
    } else {
        fire();
    }
}

- (void)finishWithImage:(UIImage *)image {
    [self finishWithImage:image dismiss:nil];
}

- (void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results API_AVAILABLE(ios(14.0)) {
    if (results.count == 0) { [self finishWithImage:nil dismiss:picker]; return; }

    PHPickerResult *result = results.firstObject;
    if (![result.itemProvider canLoadObjectOfClass:[UIImage class]]) {
        [self finishWithImage:nil dismiss:picker];
        return;
    }

    __weak typeof(self) weakSelf = self;
    [result.itemProvider loadObjectOfClass:[UIImage class]
                        completionHandler:^(id<NSItemProviderReading> _Nullable obj, NSError * _Nullable err) {
        UIImage *image = [obj isKindOfClass:[UIImage class]] ? (UIImage *)obj : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self) return;
            [self finishWithImage:image dismiss:picker];
        });
    }];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    if (!url) { [self finishWithImage:nil dismiss:controller]; return; }

    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSData *data = [NSData dataWithContentsOfURL:url options:0 error:nil];
        UIImage *image = data ? [UIImage imageWithData:data] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self) return;
            [self finishWithImage:image dismiss:controller];
        });
    });
}

- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    [self finishWithImage:nil dismiss:controller];
}

@end

#pragma mark - 图标（形状沿用 6.7.2，仅把颜色换成本页主题色）

static UIBezierPath *FBSparklePath(CGPoint cen, CGFloat r, CGFloat thin) {
    UIBezierPath *p = [UIBezierPath bezierPath];
    [p moveToPoint:CGPointMake(cen.x, cen.y - r)];
    [p addQuadCurveToPoint:CGPointMake(cen.x, cen.y + r) controlPoint:CGPointMake(cen.x + thin, cen.y)];
    [p addQuadCurveToPoint:CGPointMake(cen.x, cen.y - r) controlPoint:CGPointMake(cen.x - thin, cen.y)];
    [p closePath];
    [p moveToPoint:CGPointMake(cen.x - r, cen.y)];
    [p addQuadCurveToPoint:CGPointMake(cen.x + r, cen.y) controlPoint:CGPointMake(cen.x, cen.y - thin)];
    [p addQuadCurveToPoint:CGPointMake(cen.x - r, cen.y) controlPoint:CGPointMake(cen.x, cen.y + thin)];
    [p closePath];
    return p;
}

static UIImage *FBEntryGlyph(void) {
    const CGFloat S = 26.0;
    UIGraphicsImageRendererFormat *fmt = [UIGraphicsImageRendererFormat defaultFormat];
    fmt.opaque = NO;
    fmt.scale = 3.0;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(S, S) format:fmt];

    UIImage *img = [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGContextRef c = ctx.CGContext;
        CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
        CGRect box = CGRectMake(2.0, 4.5, 21.0, 18.0);
        UIBezierPath *frame = [UIBezierPath bezierPathWithRoundedRect:box cornerRadius:6.5];

        CGContextSaveGState(c);
        [frame addClip];
        {
            CGFloat comps[6] = { 1, 0.40, 1, 0.24, 1, 0.14 };
            CGFloat locs[3]  = { 0.0, 0.58, 1.0 };
            CGGradientRef g = CGGradientCreateWithColorComponents(cs, comps, locs, 3);
            CGContextDrawLinearGradient(c, g, CGPointMake(0, CGRectGetMinY(box)),
                                        CGPointMake(0, CGRectGetMaxY(box)), 0);
            CGGradientRelease(g);

            CGFloat comps2[6] = { 1, 0.0, 1, 0.0, 1, 0.20 };
            CGGradientRef g2 = CGGradientCreateWithColorComponents(cs, comps2, locs, 3);
            CGContextDrawLinearGradient(c, g2, CGPointMake(0, CGRectGetMidY(box)),
                                        CGPointMake(0, CGRectGetMaxY(box)), 0);
            CGGradientRelease(g2);
        }

        {
            UIBezierPath *far = [UIBezierPath bezierPath];
            [far moveToPoint:CGPointMake(4.0, 20.0)];
            [far addLineToPoint:CGPointMake(9.4, 13.2)];
            [far addLineToPoint:CGPointMake(12.6, 16.6)];
            [far addLineToPoint:CGPointMake(15.8, 12.2)];
            [far addLineToPoint:CGPointMake(21.2, 20.0)];
            [far closePath];
            [[UIColor colorWithWhite:1.0 alpha:0.55] setFill];
            [far fill];

            UIBezierPath *near = [UIBezierPath bezierPath];
            [near moveToPoint:CGPointMake(4.0, 21.0)];
            [near addLineToPoint:CGPointMake(11.0, 15.6)];
            [near addLineToPoint:CGPointMake(15.2, 19.2)];
            [near addLineToPoint:CGPointMake(18.4, 16.4)];
            [near addLineToPoint:CGPointMake(21.4, 21.0)];
            [near closePath];
            [[UIColor colorWithWhite:1.0 alpha:1.0] setFill];
            [near fill];

            UIBezierPath *sun = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(6.0, 8.0, 3.2, 3.2)];
            [[UIColor colorWithWhite:1.0 alpha:0.95] setFill];
            [sun fill];
        }
        CGContextRestoreGState(c);

        [[UIColor colorWithWhite:1.0 alpha:0.55] setStroke];
        frame.lineWidth = 1.0;
        [frame stroke];

        {
            UIBezierPath *arc = [UIBezierPath bezierPath];
            arc.lineWidth = 1.3;
            arc.lineCapStyle = kCGLineCapRound;
            [arc moveToPoint:CGPointMake(4.6, 12.6)];
            [arc addCurveToPoint:CGPointMake(13.0, 6.4) controlPoint1:CGPointMake(5.4, 8.2) controlPoint2:CGPointMake(8.6, 6.4)];
            [[UIColor colorWithWhite:1.0 alpha:0.85] setStroke];
            [arc stroke];
        }

        {
            [[UIColor colorWithWhite:1.0 alpha:1.0] setFill];
            [FBSparklePath(CGPointMake(21.6, 5.0), 4.0, 0.85) fill];
            [FBSparklePath(CGPointMake(24.4, 9.6), 1.9, 0.5) fill];
        }

        CGColorSpaceRelease(cs);
    }];

    return [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

static UIImage *FBGlassThumb(CGFloat d) {
    static NSMutableDictionary<NSNumber *, UIImage *> *cache = nil;
    if (!cache) cache = [NSMutableDictionary dictionary];
    UIImage *hit = cache[@(d)];
    if (hit) return hit;

    UIGraphicsImageRendererFormat *fmt = [UIGraphicsImageRendererFormat defaultFormat];
    fmt.scale = 3.0;
    fmt.opaque = NO;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(d, d) format:fmt];
    UIImage *img = [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGContextRef c = ctx.CGContext;
        CGRect box = CGRectInset(CGRectMake(0, 0, d, d), 1.5, 1.5);
        UIBezierPath *p = [UIBezierPath bezierPathWithOvalInRect:box];

        CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
        CGContextSaveGState(c);
        [p addClip];
        CGFloat comps[6] = { 1, 1.0, 1, 0.95, 1, 0.82 };
        CGFloat locs[3]  = { 0.0, 0.55, 1.0 };
        CGGradientRef g = CGGradientCreateWithColorComponents(cs, comps, locs, 3);
        CGContextDrawLinearGradient(c, g, CGPointMake(0, CGRectGetMinY(box)),
                                    CGPointMake(0, CGRectGetMaxY(box)), 0);
        CGGradientRelease(g);
        CGColorSpaceRelease(cs);
        CGContextRestoreGState(c);

        [[UIColor colorWithWhite:0.0 alpha:0.10] setStroke];
        p.lineWidth = 0.8;
        [p stroke];
    }];
    if (img) cache[@(d)] = img;
    return img;
}

static UIImage *FBFaintIcon(NSString *name) {
    static NSMutableDictionary<NSString *, UIImage *> *cache = nil;
    if (!cache) cache = [NSMutableDictionary dictionary];
    UIImage *hit = cache[name ?: @""];
    if (hit) return hit;

    CGFloat S = 24.0;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(S, S)];
    UIImage *img = [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        UIColor *full = [UIColor whiteColor];
        UIColor *soft = [UIColor colorWithWhite:1.0 alpha:0.4];

        if ([name isEqualToString:@"circle.lefthalf.filled"]) {
            UIBezierPath *right = [UIBezierPath bezierPath];
            [right addArcWithCenter:CGPointMake(12, 12) radius:8.5
                         startAngle:-M_PI_2 endAngle:M_PI_2 clockwise:YES];
            [right closePath];
            [soft setFill]; [right fill];

            UIBezierPath *left = [UIBezierPath bezierPath];
            [left addArcWithCenter:CGPointMake(12, 12) radius:8.5
                        startAngle:M_PI_2 endAngle:M_PI * 1.5 clockwise:YES];
            [left closePath];
            [full setFill]; [left fill];

        } else if ([name isEqualToString:@"aspectratio"]) {
            UIBezierPath *ring = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(2.5, 5, 19, 14) cornerRadius:4.0];
            [ring appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(5.5, 8, 9.5, 8) cornerRadius:2.0]];
            ring.usesEvenOddFillRule = YES;
            [full setFill]; [ring fill];

            UIBezierPath *inner = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(5.5, 8, 9.5, 8) cornerRadius:2.0];
            [soft setFill]; [inner fill];

        } else if ([name isEqualToString:@"moon.fill"] || [name isEqualToString:@"moon.stars.fill"]) {
            UIBezierPath *star = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(17.5, 4.5, 3, 3)];
            [soft setFill]; [star fill];
            UIBezierPath *moon = [UIBezierPath bezierPath];
            [moon addArcWithCenter:CGPointMake(13, 12) radius:8.5
                        startAngle:M_PI * 0.40 endAngle:M_PI * 1.60 clockwise:YES];
            [moon addArcWithCenter:CGPointMake(17.5, 9.5) radius:7.5
                        startAngle:M_PI * 1.55 endAngle:M_PI * 0.45 clockwise:NO];
            [moon closePath];
            [full setFill]; [moon fill];

        } else if ([name isEqualToString:@"sun.max.fill"]) {
            for (int i = 0; i < 8; i++) {
                CGFloat a = i * M_PI / 4.0;
                UIBezierPath *ray = [UIBezierPath bezierPath];
                ray.lineWidth = 2.6; ray.lineCapStyle = kCGLineCapRound;
                [ray moveToPoint:CGPointMake(12 + cos(a) * 6.4, 12 + sin(a) * 6.4)];
                [ray addLineToPoint:CGPointMake(12 + cos(a) * 9.4, 12 + sin(a) * 9.4)];
                [soft setStroke]; [ray stroke];
            }
            UIBezierPath *core = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(6.8, 6.8, 10.4, 10.4)];
            [full setFill]; [core fill];

        } else if ([name isEqualToString:@"wind"]) {
            NSArray *widths = @[ @17.0, @13.0, @15.0 ];
            NSArray *alphas = @[ @1.0, @0.4, @1.0 ];
            for (int i = 0; i < 3; i++) {
                CGFloat w = [widths[i] doubleValue];
                CGFloat al = [alphas[i] doubleValue];
                CGRect rr = CGRectMake(3.5, 6.0 + i * 5.4, w, 3.4);
                UIBezierPath *bar = [UIBezierPath bezierPathWithRoundedRect:rr cornerRadius:1.7];
                [[UIColor colorWithWhite:1.0 alpha:al] setFill]; [bar fill];
            }

        } else if ([name isEqualToString:@"paintpalette.fill"]) {
            NSMutableArray *dots = [NSMutableArray array];
            for (int i = 0; i < 3; i++) {
                [dots addObject:[UIBezierPath bezierPathWithOvalInRect:CGRectMake(7.2 + i * 4.0, 7.6, 2.4, 2.4)]];
            }
            UIBezierPath *dish = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(2.5, 2.5, 19, 19)];
            [dish appendPath:[UIBezierPath bezierPathWithOvalInRect:CGRectMake(13.5, 13.5, 10.5, 10.5)]];
            for (UIBezierPath *dot in dots) [dish appendPath:dot];
            dish.usesEvenOddFillRule = YES;
            [full setFill]; [dish fill];

            for (UIBezierPath *dot in dots) { [soft setFill]; [dot fill]; }

        } else if ([name isEqualToString:@"arrow.counterclockwise"]) {
            UIBezierPath *handle = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(9.5, 2.5, 5, 2) cornerRadius:1.0];
            [soft setFill]; [handle fill];

            NSMutableArray *slots = [NSMutableArray array];
            for (int i = 0; i < 3; i++) {
                CGFloat x = 9.0 + i * 3.0;
                [slots addObject:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(x - 0.8, 9.5, 1.6, 8) cornerRadius:0.8]];
            }
            UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(5, 7, 14, 13) cornerRadius:2.5];
            for (UIBezierPath *slot in slots) [body appendPath:slot];
            body.usesEvenOddFillRule = YES;
            [full setFill]; [body fill];

            for (UIBezierPath *slot in slots) { [soft setFill]; [slot fill]; }

            UIBezierPath *lid = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.5, 5, 17, 2) cornerRadius:1.0];
            [full setFill]; [lid fill];

        } else if ([name isEqualToString:@"folder"]) {
            UIBezierPath *tab = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3, 5, 9, 4) cornerRadius:1.8];
            [soft setFill]; [tab fill];
            UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3, 7, 18, 12) cornerRadius:2.5];
            [full setFill]; [body fill];

        } else if ([name isEqualToString:@"nav"]) {
            UIBezierPath *barPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.0, 4.0, 18.0, 6.0)
                                                                 cornerRadius:2.0];
            [full setFill]; [barPath fill];
            UIBezierPath *l1 = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.0, 13.0, 18.0, 3.0)
                                                            cornerRadius:1.5];
            [soft setFill]; [l1 fill];
            UIBezierPath *l2 = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.0, 18.0, 12.0, 3.0)
                                                            cornerRadius:1.5];
            [soft setFill]; [l2 fill];

        } else if ([name isEqualToString:@"rows"]) {
            NSArray *ws = @[ @17.0, @12.0, @15.0 ];
            NSArray *as = @[ @1.0, @0.45, @1.0 ];
            for (int i = 0; i < 3; i++) {
                CGFloat w = [ws[i] doubleValue];
                CGFloat al = [as[i] doubleValue];
                UIBezierPath *bar = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.5, 6.0 + i * 5.4, w, 3.2)
                                                                   cornerRadius:1.6];
                [[UIColor colorWithWhite:1.0 alpha:al] setFill];
                [bar fill];
            }

        } else if ([name isEqualToString:@"shadow"]) {
            UIBezierPath *cast = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(5.5, 8.5, 15.0, 11.0)
                                                                cornerRadius:3.5];
            [soft setFill]; [cast fill];
            UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.0, 4.5, 15.0, 11.0)
                                                                cornerRadius:3.5];
            [full setFill]; [body fill];

        } else if ([name isEqualToString:@"link"]) {
            UIBezierPath *l = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(2.5, 8.5, 12, 7) cornerRadius:3.5];
            [soft setFill]; [l fill];
            UIBezierPath *r = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(9.5, 8.5, 12, 7) cornerRadius:3.5];
            [full setFill]; [r fill];
            UIBezierPath *bar = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(8.5, 10.6, 7, 2.8) cornerRadius:1.4];
            [soft setFill]; [bar fill];

        } else if ([name isEqualToString:@"info"]) {
            UIBezierPath *ring = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(3.5, 3.5, 17, 17) cornerRadius:8.5];
            [ring appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(5.0, 5.0, 14, 14) cornerRadius:7.0]];
            ring.usesEvenOddFillRule = YES;
            [full setFill]; [ring fill];
            UIBezierPath *dot = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.8, 7.2, 2.4, 2.4)];
            [full setFill]; [dot fill];
            UIBezierPath *stem = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10.8, 11.0, 2.4, 6.4) cornerRadius:1.2];
            [soft setFill]; [stem fill];

        } else {
            UIBezierPath *dot = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(7, 7, 10, 10)];
            [full setFill]; [dot fill];
        }
    }];
    UIImage *out = [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    if (out) cache[name ?: @""] = out;
    return out;
}

#pragma mark - 缩略图（ImageIO 抽样，不解全图）

static NSMutableDictionary<NSString *, UIImage *> *gFBThumbCache = nil;

static UIImage *FBThumbnail(NSString *path, CGFloat maxSide) {
    if (path.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:path]) return nil;
    if (!gFBThumbCache) gFBThumbCache = [NSMutableDictionary dictionary];

    NSString *key = [NSString stringWithFormat:@"%@|%.0f|%.0f", path, maxSide, FBFileMTime(path)];
    UIImage *hit = gFBThumbCache[key];
    if (hit) return hit;

    UIImage *out = nil;
    NSURL *url = [NSURL fileURLWithPath:path];
    CGImageSourceRef src = CGImageSourceCreateWithURL((__bridge CFURLRef)url, NULL);
    if (src) {
        NSDictionary *opts = @{
            (id)kCGImageSourceCreateThumbnailFromImageAlways: @YES,
            (id)kCGImageSourceCreateThumbnailWithTransform: @YES,
            (id)kCGImageSourceThumbnailMaxPixelSize: @(maxSide * 2.0)
        };
        CGImageRef cg = CGImageSourceCreateThumbnailAtIndex(src, 0, (__bridge CFDictionaryRef)opts);
        if (cg) {
            out = [UIImage imageWithCGImage:cg];
            CGImageRelease(cg);
        }
        CFRelease(src);
    }
    if (out) {
        if (gFBThumbCache.count > 8) [gFBThumbCache removeAllObjects];
        gFBThumbCache[key] = out;
    }
    return out;
}

static NSString *FBBadgeText(void) {
    NSMutableArray<NSString *> *parts = [NSMutableArray array];
    [parts addObject:(FBDarkMode() && FBHasDarkImage()) ? @"深色" : @"浅色"];
    [parts addObject:FBModeName(FBMode())];
    [parts addObject:[NSString stringWithFormat:@"%.0f%%", FBAlpha() * 100]];
    if (FBBlur() > 0.5) [parts addObject:[NSString stringWithFormat:@"模糊 %@", FBBlurText()]];
    return [NSString stringWithFormat:@" %@ ", [parts componentsJoinedByString:@" · "]];
}

#pragma mark - 设置页

static const NSInteger kFBSecPreview    = 0;
static const NSInteger kFBSecDisplay    = 1;
static const NSInteger kFBSecImage      = 2;
static const NSInteger kFBSecAppearance = 3;
static const NSInteger kFBSecOther      = 4;

#pragma mark 通用 cell

@interface FBSettingCell : UITableViewCell
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UILabel *titleLbl;
@property (nonatomic, strong) UILabel *valueLbl;
@property (nonatomic, strong) UIView *extraView;
@property (nonatomic, strong) NSLayoutConstraint *valueTrailing;
@property (nonatomic, strong) NSArray<NSLayoutConstraint *> *centeredOn;
@property (nonatomic, strong) NSArray<NSLayoutConstraint *> *stackedOn;
@property (nonatomic, strong) FBGlassCardView *card;
@property (nonatomic, strong) UIView *sep;
@end

@implementation FBSettingCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse {
    self = [super initWithStyle:style reuseIdentifier:reuse];
    if (!self) return nil;

    self.backgroundColor = UIColor.clearColor;
    self.contentView.backgroundColor = UIColor.clearColor;
    self.selectionStyle = UITableViewCellSelectionStyleNone;

    _card = [[FBGlassCardView alloc] init];
    _card.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView insertSubview:_card atIndex:0];
    [NSLayoutConstraint activateConstraints:@[
        [_card.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:kFBCardInset],
        [_card.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-kFBCardInset],
        [_card.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:3],
        [_card.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-3],
    ]];

    _iconView = [[UIImageView alloc] init];
    _iconView.translatesAutoresizingMaskIntoConstraints = NO;
    _iconView.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:_iconView];

    _titleLbl = [[UILabel alloc] init];
    _titleLbl.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLbl.font = [UIFont systemFontOfSize:17 weight:UIFontWeightRegular];
    _titleLbl.textColor = UIColor.labelColor;
    _titleLbl.adjustsFontForContentSizeCategory = YES;
    [self.contentView addSubview:_titleLbl];

    _valueLbl = [[UILabel alloc] init];
    _valueLbl.translatesAutoresizingMaskIntoConstraints = NO;
    _valueLbl.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    _valueLbl.textColor = UIColor.secondaryLabelColor;
    _valueLbl.textAlignment = NSTextAlignmentRight;
    [_valueLbl setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [self.contentView addSubview:_valueLbl];

    _extraView = [[UIView alloc] init];
    _extraView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_extraView];

    _sep = [[UIView alloc] init];
    _sep.translatesAutoresizingMaskIntoConstraints = NO;
    _sep.backgroundColor = FBHairline(self.traitCollection);
    [self.contentView addSubview:_sep];

    CGFloat lead = kFBCardInset + 16.0;
    CGFloat trail = -(kFBCardInset + 16.0);

    _centeredOn = @[
        [_iconView.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor],
        [_iconView.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:lead],
        [_titleLbl.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor],
        [_titleLbl.leadingAnchor constraintEqualToAnchor:_iconView.trailingAnchor constant:14],
        [_extraView.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:10],
        [_extraView.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-10],
    ];

    _stackedOn = @[
        [_iconView.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:16],
        [_iconView.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:lead],
        [_titleLbl.centerYAnchor constraintEqualToAnchor:_iconView.centerYAnchor],
        [_titleLbl.leadingAnchor constraintEqualToAnchor:_iconView.trailingAnchor constant:14],
        [_extraView.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:48],
        [_extraView.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-12],
    ];

    [NSLayoutConstraint activateConstraints:@[
        [_iconView.widthAnchor constraintEqualToConstant:22],
        [_iconView.heightAnchor constraintEqualToConstant:22],
        [_extraView.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:lead],
        [_extraView.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:trail],
        [_titleLbl.trailingAnchor constraintLessThanOrEqualToAnchor:self.contentView.trailingAnchor constant:trail - 2],
        [_valueLbl.centerYAnchor constraintEqualToAnchor:_titleLbl.centerYAnchor],
        [_valueLbl.leadingAnchor constraintGreaterThanOrEqualToAnchor:_titleLbl.trailingAnchor constant:8],

        [_sep.leadingAnchor constraintEqualToAnchor:_titleLbl.leadingAnchor],
        [_sep.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:trail],
        [_sep.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor],
        [_sep.heightAnchor constraintEqualToConstant:1.0 / UIScreen.mainScreen.scale],
    ]];
    _valueTrailing = [_valueLbl.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:trail];
    _valueTrailing.active = YES;

    return self;
}

- (void)useStackedLayout:(BOOL)stacked {
    [NSLayoutConstraint deactivateConstraints:_centeredOn];
    [NSLayoutConstraint deactivateConstraints:_stackedOn];
    [NSLayoutConstraint activateConstraints:stacked ? _stackedOn : _centeredOn];
}

- (void)fb_styleTop:(BOOL)top bottom:(BOOL)bottom {
    UIRectCorner c = 0;
    if (top)    c |= UIRectCornerTopLeft | UIRectCornerTopRight;
    if (bottom) c |= UIRectCornerBottomLeft | UIRectCornerBottomRight;
    self.card.corners = c;
    self.sep.hidden = bottom;
    self.sep.backgroundColor = FBHairline(self.traitCollection);
}

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated {
    [super setHighlighted:highlighted animated:animated];
    self.card.highlighted = highlighted;
}

@end

#pragma mark 预览 cell

@interface FBPreviewCell : UITableViewCell
@property (nonatomic, strong) FBGlassCardView *card;
@property (nonatomic, strong) UIImageView *shot;
@property (nonatomic, strong) UIView *scrim;
@property (nonatomic, strong) UILabel *placeholder;
@property (nonatomic, strong) UILabel *badge;
@property (nonatomic, strong) UIView *chip;
@end

@implementation FBPreviewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse {
    self = [super initWithStyle:style reuseIdentifier:reuse];
    if (!self) return nil;

    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.backgroundColor = UIColor.clearColor;
    self.contentView.backgroundColor = UIColor.clearColor;

    self.backgroundView = nil;

    _card = [[FBGlassCardView alloc] init];
    _card.radius = 30.0;
    _card.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView insertSubview:_card atIndex:0];
    [NSLayoutConstraint activateConstraints:@[
        [_card.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:kFBCardInset],
        [_card.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-kFBCardInset],
        [_card.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:3],
        [_card.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-3],
    ]];

    UIView *clip = _card.clip;

    _shot = [[UIImageView alloc] initWithFrame:CGRectZero];
    _shot.translatesAutoresizingMaskIntoConstraints = NO;
    _shot.clipsToBounds = YES;
    _shot.contentMode = UIViewContentModeScaleAspectFill;
    [clip addSubview:_shot];
    [NSLayoutConstraint activateConstraints:@[
        [_shot.leadingAnchor constraintEqualToAnchor:clip.leadingAnchor],
        [_shot.trailingAnchor constraintEqualToAnchor:clip.trailingAnchor],
        [_shot.topAnchor constraintEqualToAnchor:clip.topAnchor],
        [_shot.bottomAnchor constraintEqualToAnchor:clip.bottomAnchor],
    ]];

    _scrim = [[UIView alloc] initWithFrame:CGRectZero];
    _scrim.translatesAutoresizingMaskIntoConstraints = NO;
    _scrim.userInteractionEnabled = NO;
    [clip addSubview:_scrim];
    [NSLayoutConstraint activateConstraints:@[
        [_scrim.leadingAnchor constraintEqualToAnchor:clip.leadingAnchor],
        [_scrim.trailingAnchor constraintEqualToAnchor:clip.trailingAnchor],
        [_scrim.bottomAnchor constraintEqualToAnchor:clip.bottomAnchor],
        [_scrim.heightAnchor constraintEqualToAnchor:clip.heightAnchor multiplier:0.48],
    ]];

    _placeholder = [[UILabel alloc] init];
    _placeholder.translatesAutoresizingMaskIntoConstraints = NO;
    _placeholder.text = @"还没有背景图\n在「背景图」里选一张";
    _placeholder.numberOfLines = 0;
    _placeholder.textAlignment = NSTextAlignmentCenter;
    _placeholder.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    _placeholder.textColor = UIColor.tertiaryLabelColor;
    [_card.clip addSubview:_placeholder];

    _chip = [[UIView alloc] init];
    _chip.translatesAutoresizingMaskIntoConstraints = NO;
    _chip.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.22];
    _chip.layer.cornerRadius = 11.0;
    _chip.layer.cornerCurve = kCACornerCurveContinuous;
    _chip.layer.borderWidth = 0.8;
    _chip.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.45].CGColor;
    [_card.clip addSubview:_chip];

    UILabel *chipLbl = [[UILabel alloc] init];
    chipLbl.translatesAutoresizingMaskIntoConstraints = NO;
    chipLbl.text = @"预览";
    chipLbl.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    chipLbl.textColor = UIColor.whiteColor;
    [_chip addSubview:chipLbl];

    _badge = [[UILabel alloc] init];
    _badge.translatesAutoresizingMaskIntoConstraints = NO;
    _badge.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightSemibold];
    _badge.textColor = UIColor.whiteColor;
    _badge.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.20];
    _badge.textAlignment = NSTextAlignmentCenter;
    _badge.layer.cornerRadius = 12.0;
    _badge.layer.cornerCurve = kCACornerCurveContinuous;
    _badge.layer.borderWidth = 0.8;
    _badge.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.42].CGColor;
    _badge.clipsToBounds = YES;
    [_card.clip addSubview:_badge];

    [NSLayoutConstraint activateConstraints:@[
        [_placeholder.centerXAnchor constraintEqualToAnchor:_card.clip.centerXAnchor],
        [_placeholder.centerYAnchor constraintEqualToAnchor:_card.clip.centerYAnchor],

        [_chip.leadingAnchor constraintEqualToAnchor:_card.clip.leadingAnchor constant:14],
        [_chip.topAnchor constraintEqualToAnchor:_card.clip.topAnchor constant:14],
        [_chip.heightAnchor constraintEqualToConstant:22],
        [chipLbl.leadingAnchor constraintEqualToAnchor:_chip.leadingAnchor constant:10],
        [chipLbl.trailingAnchor constraintEqualToAnchor:_chip.trailingAnchor constant:-10],
        [chipLbl.centerYAnchor constraintEqualToAnchor:_chip.centerYAnchor],

        [_badge.leadingAnchor constraintEqualToAnchor:_card.clip.leadingAnchor constant:14],
        [_badge.bottomAnchor constraintEqualToAnchor:_card.clip.bottomAnchor constant:-14],
        [_badge.heightAnchor constraintEqualToConstant:24],
        [_badge.widthAnchor constraintGreaterThanOrEqualToConstant:64],
        [_badge.trailingAnchor constraintLessThanOrEqualToAnchor:_card.clip.trailingAnchor constant:-14],
    ]];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];

    if (!self.scrim.layer.sublayers.count) {
        CAGradientLayer *g = [CAGradientLayer layer];
        g.colors = @[ (id)[UIColor colorWithWhite:0.0 alpha:0.0].CGColor,
                      (id)[UIColor colorWithWhite:0.0 alpha:0.42].CGColor ];
        [self.scrim.layer addSublayer:g];
    }
    self.scrim.layer.sublayers.firstObject.frame = self.scrim.bounds;
}

@end

#pragma mark 背景光晕（Liquid Glass 底色）

@interface FBBackdropView : UIView
@property (nonatomic, strong) CAGradientLayer *topGlow;
@property (nonatomic, strong) CAGradientLayer *bottomGlow;
@end

@implementation FBBackdropView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.userInteractionEnabled = NO;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

    _topGlow = [CAGradientLayer layer];
    _topGlow.type = kCAGradientLayerRadial;
    _topGlow.startPoint = CGPointMake(0.5, 0.0);
    _topGlow.endPoint = CGPointMake(1.0, 0.9);
    [self.layer addSublayer:_topGlow];

    _bottomGlow = [CAGradientLayer layer];
    _bottomGlow.type = kCAGradientLayerRadial;
    _bottomGlow.startPoint = CGPointMake(0.2, 1.0);
    _bottomGlow.endPoint = CGPointMake(0.9, 0.3);
    [self.layer addSublayer:_bottomGlow];

    [self fb_refreshColors];
    return self;
}

- (void)fb_refreshColors {
    UIColor *accent = FBAccentColor();
    BOOL dark = (self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark);
    CGFloat aTop = dark ? 0.34 : 0.22;
    CGFloat aBottom = dark ? 0.26 : 0.16;

    self.topGlow.colors = @[ (id)[accent colorWithAlphaComponent:aTop].CGColor,
                             (id)[accent colorWithAlphaComponent:aTop * 0.35].CGColor,
                             (id)[UIColor clearColor].CGColor ];
    self.topGlow.locations = @[ @0.0, @0.45, @1.0 ];

    UIColor *cool = [UIColor colorWithRed:0.42 green:0.36 blue:0.98 alpha:1.0];
    self.bottomGlow.colors = @[ (id)[cool colorWithAlphaComponent:aBottom].CGColor,
                                (id)[cool colorWithAlphaComponent:aBottom * 0.3].CGColor,
                                (id)[UIColor clearColor].CGColor ];
    self.bottomGlow.locations = @[ @0.0, @0.5, @1.0 ];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    CGRect b = self.bounds;
    self.topGlow.frame = CGRectMake(-b.size.width * 0.3, -b.size.height * 0.28,
                                    b.size.width * 1.5, b.size.height * 0.62);
    self.bottomGlow.frame = CGRectMake(-b.size.width * 0.35, b.size.height * 0.55,
                                       b.size.width * 1.5, b.size.height * 0.6);
    [CATransaction commit];
}

- (void)traitCollectionDidChange:(UITraitCollection *)prev {
    [super traitCollectionDidChange:prev];
    if (prev.userInterfaceStyle != self.traitCollection.userInterfaceStyle) [self fb_refreshColors];
}

@end

#pragma mark 设置控制器

@interface FBSettingsController : UITableViewController
@property (nonatomic, strong) FBImagePickerHostController *pickerHost;
@property (nonatomic, strong) UINavigationBarAppearance *fb_prevStandard;
@property (nonatomic, strong) UINavigationBarAppearance *fb_prevScrollEdge;
@end

@implementation FBSettingsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"背景设置";

    self.tableView.backgroundColor = UIColor.clearColor;
    self.tableView.backgroundView = [[FBBackdropView alloc] initWithFrame:self.view.bounds];
    self.tableView.tintColor = FBAccentColor();
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.contentInset = UIEdgeInsetsMake(4, 0, 30, 0);
    if (@available(iOS 15.0, *)) {
        self.tableView.sectionHeaderTopPadding = 0;
    }

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(fb_imageReady)
                                                 name:FBImageReadyName
                                               object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tableView.tintColor = FBAccentColor();
    self.navigationController.navigationBar.tintColor = FBAccentColor();
    [self fb_applyGlassNavAppearance];
    if ([self.tableView.backgroundView isKindOfClass:[FBBackdropView class]]) {
        [(FBBackdropView *)self.tableView.backgroundView fb_refreshColors];
    }
    [self.tableView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (!FBGlobalTintOn()) self.navigationController.navigationBar.tintColor = nil;
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    UIViewController *top = self.navigationController.topViewController;
    if (top && top != self) [self fb_restoreNavAppearance];

    FBApplyListPolishToAll();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ FBApplyListPolishToAll(); });
}

- (void)fb_applyGlassNavAppearance {
    UINavigationBar *bar = self.navigationController.navigationBar;
    if (!bar) return;
    if (self.fb_prevStandard) return;

    self.fb_prevStandard = bar.standardAppearance;
    self.fb_prevScrollEdge = bar.scrollEdgeAppearance;

    UINavigationBarAppearance *ap = [[UINavigationBarAppearance alloc] init];

    [ap configureWithDefaultBackground];
    ap.backgroundColor = [UIColor.systemBackgroundColor colorWithAlphaComponent:0.78];
    ap.shadowColor = UIColor.clearColor;
    ap.titleTextAttributes = @{
        NSFontAttributeName: [UIFont systemFontOfSize:17 weight:UIFontWeightBold],
        NSForegroundColorAttributeName: UIColor.labelColor
    };
    bar.standardAppearance = ap;
    bar.scrollEdgeAppearance = ap;
    if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = ap;
}

- (void)fb_restoreNavAppearance {
    UINavigationBar *bar = self.navigationController.navigationBar;
    if (!bar || !self.fb_prevStandard) return;
    bar.standardAppearance = self.fb_prevStandard;
    bar.scrollEdgeAppearance = self.fb_prevScrollEdge;
    if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = self.fb_prevScrollEdge;
    self.fb_prevStandard = nil;
    self.fb_prevScrollEdge = nil;
}

#pragma mark 结构

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv { return 5; }

- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s {
    switch (s) {
        case kFBSecPreview:    return 1;
        case kFBSecDisplay:    return 3;
        case kFBSecImage:      return 2;
        case kFBSecAppearance: return 9;
        case kFBSecOther:      return 2;
        default: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)s {
    switch (s) {
        case kFBSecDisplay:    return @"显示";
        case kFBSecImage:      return @"背景图";
        case kFBSecAppearance: return @"外观";
        case kFBSecOther:      return @"其他";
        default: return nil;
    }
}

- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)s {
    if (s == kFBSecDisplay) {
        return [NSString stringWithFormat:@"透明度 %.0f%%–%.0f%%，数值越大越清楚；模糊 0–%.0f，双击数值可精确输入。",
                kFBAlphaMin * 100, kFBAlphaMax * 100, kFBBlurMax];
    }
    if (s == kFBSecAppearance) {
        return @"接管后 Filza 的返回箭头、开关、选中高亮都会跟随主题色；关掉即恢复系统蓝。";
    }
    if (s == kFBSecOther) {
        return [NSString stringWithFormat:@"FilzaBackground %@  ·  RootHide", FBVersion];
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tv heightForRowAtIndexPath:(NSIndexPath *)ip {
    if (ip.section == kFBSecPreview) return 220.0;
    if (ip.section == kFBSecDisplay && (ip.row == 0 || ip.row == 1)) return 98.0;
    if (ip.section == kFBSecAppearance && (ip.row == 0 || ip.row == 7 || ip.row == 8)) return 108.0;
    return kFBRowHeight + 6.0;
}

- (NSInteger)fb_rowsInSection:(NSInteger)s {
    return [self tableView:self.tableView numberOfRowsInSection:s];
}

#pragma mark 分组标题 / 说明 / 小组件

- (NSDictionary *)fb_footerAttrs {
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    ps.lineSpacing = 2.0;
    return @{
        NSFontAttributeName: [UIFont systemFontOfSize:12 weight:UIFontWeightRegular],
        NSForegroundColorAttributeName: UIColor.tertiaryLabelColor,
        NSParagraphStyleAttributeName: ps
    };
}

- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)s {
    NSString *t = [self tableView:tv titleForHeaderInSection:s];
    if (t.length == 0) return nil;

    UIView *wrap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(tv.bounds), 32.0)];
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(kFBCardInset + 8.0, 10.0,
                                                          CGRectGetWidth(tv.bounds) - (kFBCardInset * 2 + 16), 20.0)];
    l.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    l.attributedText = [[NSAttributedString alloc] initWithString:t attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold],
        NSForegroundColorAttributeName: [UIColor.secondaryLabelColor colorWithAlphaComponent:0.92],
        NSKernAttributeName: @(0.8)
    }];
    [wrap addSubview:l];
    return wrap;
}

- (UIView *)tableView:(UITableView *)tv viewForFooterInSection:(NSInteger)s {
    NSString *t = [self tableView:tv titleForFooterInSection:s];
    if (t.length == 0) return nil;

    CGFloat w = CGRectGetWidth(tv.bounds) - (kFBCardInset * 2 + 20);
    NSAttributedString *as = [[NSAttributedString alloc] initWithString:t attributes:[self fb_footerAttrs]];
    CGRect r = [as boundingRectWithSize:CGSizeMake(w, CGFLOAT_MAX)
                                options:NSStringDrawingUsesLineFragmentOrigin
                                context:nil];

    UIView *wrap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(tv.bounds), ceil(CGRectGetHeight(r)) + 16.0)];
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(kFBCardInset + 8.0, 8.0, w, ceil(CGRectGetHeight(r)))];
    l.numberOfLines = 0;
    l.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    l.attributedText = as;
    [wrap addSubview:l];
    return wrap;
}

- (CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)s {
    return [self tableView:tv titleForHeaderInSection:s].length ? 32.0 : 6.0;
}

- (CGFloat)tableView:(UITableView *)tv heightForFooterInSection:(NSInteger)s {
    NSString *t = [self tableView:tv titleForFooterInSection:s];
    if (t.length == 0) return 6.0;
    CGFloat tvW = MAX(CGRectGetWidth(tv.bounds), CGRectGetWidth(self.view.bounds));
    CGFloat w = MAX(80.0, tvW - (kFBCardInset * 2 + 20));
    NSAttributedString *as = [[NSAttributedString alloc] initWithString:t attributes:[self fb_footerAttrs]];
    CGRect r = [as boundingRectWithSize:CGSizeMake(w, CGFLOAT_MAX)
                                options:NSStringDrawingUsesLineFragmentOrigin
                                context:nil];
    return ceil(CGRectGetHeight(r)) + 16.0;
}

- (UISlider *)fb_sliderMin:(CGFloat)mn max:(CGFloat)mx value:(CGFloat)v {
    UISlider *s = [[UISlider alloc] initWithFrame:CGRectZero];
    s.translatesAutoresizingMaskIntoConstraints = NO;
    s.minimumValue = mn;
    s.maximumValue = mx;
    s.value = v;
    s.continuous = YES;
    s.minimumTrackTintColor = FBAccentColor();
    s.maximumTrackTintColor = [UIColor colorWithWhite:0.5 alpha:0.20];
    UIImage *thumb = FBGlassThumb(26.0);
    [s setThumbImage:thumb forState:UIControlStateNormal];
    [s setThumbImage:thumb forState:UIControlStateHighlighted];
    return s;
}

- (UIView *)fb_accessory:(UIView *)v pad:(CGFloat)pad {
    CGRect f = v.frame;
    CGFloat h = MAX(CGRectGetHeight(f), 30.0);
    UIView *box = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(f) + pad, h)];
    v.frame = CGRectMake(0, (h - CGRectGetHeight(f)) / 2.0, CGRectGetWidth(f), CGRectGetHeight(f));
    [box addSubview:v];
    return box;
}

- (UIView *)fb_chevronAccessory {
    UIImage *img = [UIImage systemImageNamed:@"chevron.right"
                           withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:13
                                                                                            weight:UIImageSymbolWeightSemibold]];
    UIImageView *iv = [[UIImageView alloc] initWithImage:img];
    iv.tintColor = [UIColor.tertiaryLabelColor colorWithAlphaComponent:0.8];
    iv.contentMode = UIViewContentModeCenter;
    iv.frame = CGRectMake(0, 0, 12.0, 30.0);
    return [self fb_accessory:iv pad:22.0];
}

#pragma mark 单元格

- (void)fb_applyIcon:(NSString *)name cell:(FBSettingCell *)cell {
    cell.iconView.image = FBFaintIcon(name);
    cell.iconView.tintColor = FBAccentColor();
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    NSFileManager *fm = [NSFileManager defaultManager];

    if (ip.section == kFBSecPreview) {
        static NSString *reuse = @"FBPreviewCell";
        FBPreviewCell *cell = [tv dequeueReusableCellWithIdentifier:reuse];
        if (!cell) cell = [[FBPreviewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];

        NSString *path = FBCurrentPath();
        BOOL has = path.length && [fm fileExistsAtPath:path];
        cell.placeholder.hidden = has;
        cell.shot.hidden = !has;
        if (has) {
            cell.shot.image = FBScaledImage();
            cell.shot.contentMode = FBContentModeForMode(FBMode());
            cell.shot.alpha = FBAlpha();
        }
        cell.badge.text = has ? FBBadgeText() : @"未设置";
        cell.chip.hidden = !has;
        return cell;
    }

    static NSString *reuse = @"FBSettingCell";
    FBSettingCell *cell = [tv dequeueReusableCellWithIdentifier:reuse];
    if (!cell) cell = [[FBSettingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];

    for (UIView *v in [cell.extraView.subviews copy]) [v removeFromSuperview];
    for (UIView *v in [cell.contentView.subviews copy]) {
        if (v.tag == kFBVTagTrailing) [v removeFromSuperview];
    }
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;

    if (cell.selectedBackgroundView.tag != 0x46424742) {
        UIView *v = [[UIView alloc] init];
        v.tag = 0x46424742;
        v.backgroundColor = UIColor.clearColor;
        cell.selectedBackgroundView = v;
    }
    if (cell.backgroundView.tag != 0x46424742) {
        UIView *v = [[UIView alloc] init];
        v.tag = 0x46424742;
        v.backgroundColor = UIColor.clearColor;
        cell.backgroundView = v;
    }
    cell.titleLbl.textColor = UIColor.labelColor;
    cell.titleLbl.font = [UIFont systemFontOfSize:17 weight:UIFontWeightRegular];
    cell.valueLbl.text = nil;
    cell.valueLbl.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    cell.valueLbl.textColor = UIColor.secondaryLabelColor;
    cell.valueLbl.userInteractionEnabled = NO;
    cell.valueTrailing.constant = -(kFBCardInset + 16.0);
    [cell useStackedLayout:NO];
    cell.sep.hidden = YES;

    if (ip.section == kFBSecDisplay && ip.row == 0) {
        [cell useStackedLayout:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLbl.text = @"背景透明度";
        [self fb_applyIcon:@"circle.lefthalf.filled" cell:cell];

        cell.valueLbl.text = [NSString stringWithFormat:@"%.0f%%", FBAlpha() * 100];
        cell.valueLbl.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
        cell.valueLbl.textColor = FBAccentColor();
        cell.valueLbl.userInteractionEnabled = YES;
        for (UIGestureRecognizer *gr in [cell.valueLbl.gestureRecognizers copy]) {
            [cell.valueLbl removeGestureRecognizer:gr];
        }
        UITapGestureRecognizer *alphaTap =
            [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fb_tapAlphaValue:)];
        alphaTap.numberOfTapsRequired = 2;
        [cell.valueLbl addGestureRecognizer:alphaTap];

        UISlider *slider = [self fb_sliderMin:kFBAlphaMin max:kFBAlphaMax value:FBAlpha()];
        [slider addTarget:self action:@selector(alphaChanged:) forControlEvents:UIControlEventValueChanged];
        [slider addTarget:self action:@selector(alphaChangedEnded:)
         forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        [cell.extraView addSubview:slider];
        [NSLayoutConstraint activateConstraints:@[
            [slider.leadingAnchor constraintEqualToAnchor:cell.extraView.leadingAnchor],
            [slider.trailingAnchor constraintEqualToAnchor:cell.extraView.trailingAnchor],
            [slider.centerYAnchor constraintEqualToAnchor:cell.extraView.centerYAnchor],
            [slider.heightAnchor constraintEqualToConstant:34.0],
        ]];

    } else if (ip.section == kFBSecDisplay && ip.row == 1) {
        [cell useStackedLayout:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLbl.text = @"背景模糊";
        [self fb_applyIcon:@"wind" cell:cell];

        cell.valueLbl.text = FBBlurText();
        cell.valueLbl.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
        cell.valueLbl.textColor = FBAccentColor();
        cell.valueLbl.userInteractionEnabled = YES;
        for (UIGestureRecognizer *gr in [cell.valueLbl.gestureRecognizers copy]) {
            [cell.valueLbl removeGestureRecognizer:gr];
        }
        UITapGestureRecognizer *blurTap =
            [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fb_tapBlurValue:)];
        blurTap.numberOfTapsRequired = 2;
        [cell.valueLbl addGestureRecognizer:blurTap];

        UISlider *slider = [self fb_sliderMin:kFBBlurMin max:kFBBlurMax value:FBBlur()];
        [slider addTarget:self action:@selector(blurChanged:) forControlEvents:UIControlEventValueChanged];
        [slider addTarget:self action:@selector(blurChangedEnded:)
         forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        [cell.extraView addSubview:slider];
        [NSLayoutConstraint activateConstraints:@[
            [slider.leadingAnchor constraintEqualToAnchor:cell.extraView.leadingAnchor],
            [slider.trailingAnchor constraintEqualToAnchor:cell.extraView.trailingAnchor],
            [slider.centerYAnchor constraintEqualToAnchor:cell.extraView.centerYAnchor],
            [slider.heightAnchor constraintEqualToConstant:34.0],
        ]];

    } else if (ip.section == kFBSecDisplay && ip.row == 2) {
        cell.titleLbl.text = @"图片显示方式";
        cell.valueLbl.text = FBModeName(FBMode());
        [self fb_attachChevron:cell];
        cell.valueTrailing.constant = -(kFBCardInset + 14.0 + 12.0 + 10.0);
        [self fb_applyIcon:@"aspectratio" cell:cell];

    } else if (ip.section == kFBSecImage && ip.row == 0) {
        BOOL has = [fm fileExistsAtPath:FBImage()];
        cell.titleLbl.text = @"浅色背景图";
        cell.valueLbl.text = has ? @"已设置" : @"未设置";
        cell.valueLbl.textColor = has ? FBAccentColor() : UIColor.secondaryLabelColor;
        [self fb_applyIcon:@"sun.max.fill" cell:cell];
        if (has) {
            [self fb_attachThumb:FBImage() cell:cell];
            cell.valueTrailing.constant = -(kFBCardInset + 14.0 + 44.0 + 10.0);
        }

    } else if (ip.section == kFBSecImage && ip.row == 1) {
        BOOL has = [fm fileExistsAtPath:FBDarkImage()];
        cell.titleLbl.text = @"深色背景图";
        cell.valueLbl.text = has ? @"已设置" : @"未设置";
        cell.valueLbl.textColor = has ? FBAccentColor() : UIColor.secondaryLabelColor;
        [self fb_applyIcon:@"moon.fill" cell:cell];
        if (has) {
            [self fb_attachThumb:FBDarkImage() cell:cell];
            cell.valueTrailing.constant = -(kFBCardInset + 14.0 + 44.0 + 10.0);
        }

    } else if (ip.section == kFBSecAppearance && ip.row == 0) {
        [cell useStackedLayout:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLbl.text = @"主题色";
        [self fb_applyIcon:@"paintpalette.fill" cell:cell];

        NSString *current = FBAccentHex();
        NSArray<NSString *> *palette = FBPalette();

        UIStackView *row = [[UIStackView alloc] init];
        row.translatesAutoresizingMaskIntoConstraints = NO;
        row.axis = UILayoutConstraintAxisHorizontal;
        row.distribution = UIStackViewDistributionEqualSpacing;
        row.alignment = UIStackViewAlignmentCenter;
        [cell.extraView addSubview:row];

        for (NSUInteger i = 0; i < palette.count; i++) {
            NSString *hex = palette[i];
            UIColor *col = FBColorFromHex(hex, 1.0);
            BOOL sel = [hex.lowercaseString isEqualToString:current.lowercaseString];

            UIButton *dot = [UIButton buttonWithType:UIButtonTypeCustom];
            dot.tag = (NSInteger)i;
            dot.translatesAutoresizingMaskIntoConstraints = NO;
            dot.backgroundColor = col;
            dot.layer.cornerRadius = 16.0;
            dot.layer.cornerCurve = kCACornerCurveContinuous;
            dot.layer.borderWidth = sel ? 3.0 : 1.0;
            dot.layer.borderColor = (sel ? [UIColor colorWithWhite:1.0 alpha:0.95]
                                         : [UIColor colorWithWhite:1.0 alpha:0.30]).CGColor;
            if (sel) {
                dot.layer.shadowColor = col.CGColor;
                dot.layer.shadowOpacity = 0.70;
                dot.layer.shadowRadius = 9.0;
                dot.layer.shadowOffset = CGSizeZero;
            }
            [dot.widthAnchor constraintEqualToConstant:32.0].active = YES;
            [dot.heightAnchor constraintEqualToConstant:32.0].active = YES;
            [dot addTarget:self action:@selector(fb_swatchTapped:) forControlEvents:UIControlEventTouchUpInside];
            [row addArrangedSubview:dot];
        }
        [NSLayoutConstraint activateConstraints:@[
            [row.leadingAnchor constraintEqualToAnchor:cell.extraView.leadingAnchor],
            [row.trailingAnchor constraintEqualToAnchor:cell.extraView.trailingAnchor],
            [row.centerYAnchor constraintEqualToAnchor:cell.extraView.centerYAnchor],
            [row.heightAnchor constraintEqualToConstant:34.0],
        ]];

    } else if (ip.section == kFBSecAppearance && ip.row == 1) {
        cell.titleLbl.text = @"接管 Filza 强调色";
        [self fb_applyIcon:@"link" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBGlobalTintOn();
        [sw addTarget:self action:@selector(fb_globalToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 2) {
        cell.titleLbl.text = @"卡片阴影";
        [self fb_applyIcon:@"shadow" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBShadowOn();
        [sw addTarget:self action:@selector(fb_shadowToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 3) {
        cell.titleLbl.text = @"列表美化";
        [self fb_applyIcon:@"rows" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBListPolishOn();
        [sw addTarget:self action:@selector(fb_listPolishToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 4) {
        cell.titleLbl.text = @"Filza 导航栏";
        [self fb_applyIcon:@"nav" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBHostNavGlassOn();
        [sw addTarget:self action:@selector(fb_hostNavToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 5) {
        cell.titleLbl.text = @"底部工具栏";
        [self fb_applyIcon:@"nav" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBHostBarGlassOn();
        [sw addTarget:self action:@selector(fb_hostBarToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 6) {
        cell.titleLbl.text = @"底栏下移";
        [self fb_applyIcon:@"nav" cell:cell];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [[UISwitch alloc] init];
        sw.onTintColor = FBAccentColor();
        sw.on = FBHostBarOffsetOn();
        [sw addTarget:self action:@selector(fb_hostBarYOnToggled:) forControlEvents:UIControlEventValueChanged];
        [self fb_attachSwitch:sw cell:cell];

    } else if (ip.section == kFBSecAppearance && ip.row == 7) {
        [cell useStackedLayout:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLbl.text = @"底栏位置";
        [self fb_applyIcon:@"nav" cell:cell];
        cell.valueLbl.text = [NSString stringWithFormat:@"%.0f", FBHostBarOffset()];
        cell.valueLbl.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
        cell.valueLbl.textColor = FBAccentColor();

        UISlider *slider = [self fb_sliderMin:0 max:30 value:FBHostBarOffset()];
        [slider addTarget:self action:@selector(fb_hostBarYChanged:) forControlEvents:UIControlEventValueChanged];
        [slider addTarget:self action:@selector(fb_hostBarYEnded:)
         forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        [cell.extraView addSubview:slider];
        [NSLayoutConstraint activateConstraints:@[
            [slider.leadingAnchor constraintEqualToAnchor:cell.extraView.leadingAnchor],
            [slider.trailingAnchor constraintEqualToAnchor:cell.extraView.trailingAnchor],
            [slider.centerYAnchor constraintEqualToAnchor:cell.extraView.centerYAnchor],
            [slider.heightAnchor constraintEqualToConstant:34.0],
        ]];

    } else if (ip.section == kFBSecAppearance && ip.row == 8) {
        [cell useStackedLayout:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLbl.text = @"列表留白";
        [self fb_applyIcon:@"rows" cell:cell];

        cell.valueLbl.text = [NSString stringWithFormat:@"%.0f", FBListPad()];
        cell.valueLbl.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
        cell.valueLbl.textColor = FBAccentColor();
        cell.valueLbl.userInteractionEnabled = YES;
        for (UIGestureRecognizer *gr in [cell.valueLbl.gestureRecognizers copy]) {
            [cell.valueLbl removeGestureRecognizer:gr];
        }
        UITapGestureRecognizer *padTap =
            [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fb_tapListPadValue:)];
        padTap.numberOfTapsRequired = 2;
        [cell.valueLbl addGestureRecognizer:padTap];

        UISlider *slider = [self fb_sliderMin:kFBListPadMin max:kFBListPadMax value:FBListPad()];
        [slider addTarget:self action:@selector(fb_listPadChanged:) forControlEvents:UIControlEventValueChanged];
        [slider addTarget:self action:@selector(fb_listPadEnded:)
         forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        [cell.extraView addSubview:slider];
        [NSLayoutConstraint activateConstraints:@[
            [slider.leadingAnchor constraintEqualToAnchor:cell.extraView.leadingAnchor],
            [slider.trailingAnchor constraintEqualToAnchor:cell.extraView.trailingAnchor],
            [slider.centerYAnchor constraintEqualToAnchor:cell.extraView.centerYAnchor],
            [slider.heightAnchor constraintEqualToConstant:34.0],
        ]];

    } else if (ip.section == kFBSecOther && ip.row == 0) {
        cell.titleLbl.text = @"恢复默认背景";
        cell.titleLbl.textColor = UIColor.systemRedColor;
        [self fb_applyIcon:@"arrow.counterclockwise" cell:cell];

    } else if (ip.section == kFBSecOther && ip.row == 1) {
        cell.titleLbl.text = @"图片存放路径";
        [self fb_applyIcon:@"folder" cell:cell];
        [self fb_attachChevron:cell];
        cell.valueTrailing.constant = -(kFBCardInset + 14.0 + 12.0 + 10.0);
    }

    return cell;
}

- (CGFloat)fb_cardTrailing { return -(kFBCardInset + 14.0); }

- (void)fb_attachChevron:(FBSettingCell *)cell {
    UIImage *img = [UIImage systemImageNamed:@"chevron.right"
                           withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:13
                                                                                            weight:UIImageSymbolWeightSemibold]];
    UIImageView *iv = [[UIImageView alloc] initWithImage:img];
    iv.tag = kFBVTagTrailing;
    iv.translatesAutoresizingMaskIntoConstraints = NO;
    iv.tintColor = [UIColor.tertiaryLabelColor colorWithAlphaComponent:0.85];
    iv.contentMode = UIViewContentModeCenter;
    [cell.contentView addSubview:iv];
    [NSLayoutConstraint activateConstraints:@[
        [iv.trailingAnchor constraintEqualToAnchor:cell.contentView.trailingAnchor
                                          constant:[self fb_cardTrailing]],
        [iv.centerYAnchor constraintEqualToAnchor:cell.contentView.centerYAnchor],
        [iv.widthAnchor constraintEqualToConstant:12.0],
        [iv.heightAnchor constraintEqualToConstant:30.0],
    ]];
}

- (void)fb_attachSwitch:(UISwitch *)sw cell:(FBSettingCell *)cell {
    sw.tag = kFBVTagTrailing;
    sw.translatesAutoresizingMaskIntoConstraints = NO;
    [cell.contentView addSubview:sw];
    [NSLayoutConstraint activateConstraints:@[
        [sw.trailingAnchor constraintEqualToAnchor:cell.contentView.trailingAnchor
                                          constant:[self fb_cardTrailing]],
        [sw.centerYAnchor constraintEqualToAnchor:cell.contentView.centerYAnchor],
    ]];
}

- (void)fb_attachThumb:(NSString *)path cell:(FBSettingCell *)cell {
    UIImageView *iv = [[UIImageView alloc] init];
    iv.tag = kFBVTagTrailing;
    iv.translatesAutoresizingMaskIntoConstraints = NO;
    iv.image = FBThumbnail(path, 44.0);
    iv.contentMode = UIViewContentModeScaleAspectFill;
    iv.clipsToBounds = YES;
    iv.layer.cornerRadius = 10.0;
    iv.layer.cornerCurve = kCACornerCurveContinuous;
    iv.backgroundColor = UIColor.tertiarySystemFillColor;
    iv.layer.borderWidth = 0.8;
    iv.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.5].CGColor;
    [cell.contentView addSubview:iv];
    [NSLayoutConstraint activateConstraints:@[
        [iv.trailingAnchor constraintEqualToAnchor:cell.contentView.trailingAnchor
                                          constant:-(kFBCardInset + 14.0)],
        [iv.centerYAnchor constraintEqualToAnchor:cell.contentView.centerYAnchor],
        [iv.widthAnchor constraintEqualToConstant:44.0],
        [iv.heightAnchor constraintEqualToConstant:32.0],
    ]];
}

- (UIView *)fb_thumbViewForPath:(NSString *)path {
    CGFloat h = 38.0, w = 50.0;
    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    iv.image = FBThumbnail(path, MAX(w, h));
    iv.contentMode = UIViewContentModeScaleAspectFill;
    iv.clipsToBounds = YES;
    iv.layer.cornerRadius = 12.0;
    iv.layer.cornerCurve = kCACornerCurveContinuous;
    iv.backgroundColor = UIColor.tertiarySystemFillColor;
    iv.layer.borderWidth = 1.0;
    iv.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.55].CGColor;
    return iv;
}

#pragma mark 交互

- (void)alphaChanged:(UISlider *)slider {
    FBSetAlpha(slider.value);
    FBApplyAlphaToAll();

    FBSettingCell *alphaCell = (FBSettingCell *)[self.tableView cellForRowAtIndexPath:
                                                 [NSIndexPath indexPathForRow:0 inSection:kFBSecDisplay]];
    if ([alphaCell isKindOfClass:[FBSettingCell class]]) {
        alphaCell.valueLbl.text = [NSString stringWithFormat:@"%.0f%%", slider.value * 100];
    }

    FBPreviewCell *preview = (FBPreviewCell *)[self.tableView cellForRowAtIndexPath:
                                               [NSIndexPath indexPathForRow:0 inSection:kFBSecPreview]];
    if ([preview isKindOfClass:[FBPreviewCell class]]) {
        preview.shot.alpha = slider.value;
        preview.badge.text = FBBadgeText();
    }
}

- (void)alphaChangedEnded:(UISlider *)slider {
    FBSetAlpha(slider.value);
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)blurChanged:(UISlider *)slider {
    FBSetBlur(slider.value);

    FBSettingCell *blurCell = (FBSettingCell *)[self.tableView cellForRowAtIndexPath:
                                                [NSIndexPath indexPathForRow:1 inSection:kFBSecDisplay]];
    if ([blurCell isKindOfClass:[FBSettingCell class]]) blurCell.valueLbl.text = FBBlurText();

    FBPreviewCell *preview = (FBPreviewCell *)[self.tableView cellForRowAtIndexPath:
                                               [NSIndexPath indexPathForRow:0 inSection:kFBSecPreview]];
    if ([preview isKindOfClass:[FBPreviewCell class]]) preview.badge.text = FBBadgeText();

    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(fb_applyBlurDebounced) object:nil];
    [self performSelector:@selector(fb_applyBlurDebounced) withObject:nil afterDelay:0.25];
}

- (void)fb_applyBlurDebounced {
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBRequestImageRebuild();
}

- (void)blurChangedEnded:(UISlider *)slider {
    CGFloat snapped = round(FBClamp(slider.value, kFBBlurMin, kFBBlurMax));
    slider.value = snapped;
    FBSetBlur(snapped);
    [[NSUserDefaults standardUserDefaults] synchronize];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(fb_applyBlurDebounced) object:nil];
    FBRequestImageRebuild();
}

- (void)fb_imageReady {
    [self.tableView reloadRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:0 inSection:kFBSecPreview] ]
                          withRowAnimation:UITableViewRowAnimationNone];
}

- (void)fb_tapAlphaValue:(UITapGestureRecognizer *)g {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"背景透明度"
                                                              message:[NSString stringWithFormat:
                                         @"范围 %.0f%%–%.0f%%，数值越大背景越清楚",
                                         kFBAlphaMin * 100, kFBAlphaMax * 100]
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = [NSString stringWithFormat:@"%.0f–%.0f", kFBAlphaMin * 100, kFBAlphaMax * 100];
        tf.keyboardType = UIKeyboardTypeNumberPad;
        tf.textAlignment = NSTextAlignmentCenter;
        tf.text = [NSString stringWithFormat:@"%.0f", FBAlpha() * 100];
    }];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        CGFloat pct = [a.textFields.firstObject.text doubleValue];
        FBSetAlpha(pct / 100.0);
        [[NSUserDefaults standardUserDefaults] synchronize];
        FBApplyAlphaToAll();
        [self.tableView reloadData];
    }]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)fb_tapBlurValue:(UITapGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateEnded) return;

    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"背景模糊"
                                                              message:[NSString stringWithFormat:
                                         @"范围 %.0f–%.0f 的整数，0 表示关闭模糊",
                                         kFBBlurMin, kFBBlurMax]
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = [NSString stringWithFormat:@"%.0f–%.0f", kFBBlurMin, kFBBlurMax];
        tf.keyboardType = UIKeyboardTypeNumberPad;
        tf.textAlignment = NSTextAlignmentCenter;
        tf.text = [NSString stringWithFormat:@"%.0f", FBBlur()];
        tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];

    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        NSString *raw = a.textFields.firstObject.text ?: @"";
        NSString *trimmed = [raw stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (trimmed.length == 0) return;

        CGFloat v = [trimmed doubleValue];
        if (v < kFBBlurMin) v = kFBBlurMin;
        if (v > kFBBlurMax) v = kFBBlurMax;
        v = round(v);

        FBSetBlur(v);
        [[NSUserDefaults standardUserDefaults] synchronize];
        FBRequestImageRebuild();
        [self.tableView reloadData];
    }]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)fb_swatchTapped:(UIButton *)sender {
    NSArray<NSString *> *palette = FBPalette();
    if (sender.tag < 0 || (NSUInteger)sender.tag >= palette.count) return;

    [[NSUserDefaults standardUserDefaults] setObject:palette[(NSUInteger)sender.tag] forKey:FBAccentKey];
    [[NSUserDefaults standardUserDefaults] synchronize];

    self.tableView.tintColor = FBAccentColor();
    self.navigationController.navigationBar.tintColor = FBAccentColor();
    [self fb_applyGlassNavAppearance];
    if ([self.tableView.backgroundView isKindOfClass:[FBBackdropView class]]) {
        [(FBBackdropView *)self.tableView.backgroundView fb_refreshColors];
    }
    FBApplyGlobalTint();
    [self.tableView reloadData];
}

- (void)fb_listPolishToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBListPolishKey];
    [[NSUserDefaults standardUserDefaults] synchronize];

    FBApplyListPolishToAll();

    for (int i = 1; i <= 2; i++) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * i * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ FBApplyListPolishToAll(); });
    }
    [self.tableView reloadData];
}

- (void)fb_listPadChanged:(UISlider *)slider {
    FBSetListPad(round(slider.value));
    FBSettingCell *c = (FBSettingCell *)[self.tableView cellForRowAtIndexPath:
                                         [NSIndexPath indexPathForRow:8 inSection:kFBSecAppearance]];
    if ([c isKindOfClass:[FBSettingCell class]]) {
        c.valueLbl.text = [NSString stringWithFormat:@"%.0f", FBListPad()];
    }
    FBApplyListPolishToAll();
}

- (void)fb_listPadEnded:(UISlider *)slider {
    slider.value = round(slider.value);
    FBSetListPad(slider.value);
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBApplyListPolishToAll();
}

- (void)fb_tapListPadValue:(UITapGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateEnded) return;

    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"列表留白"
                                                              message:[NSString stringWithFormat:
                                         @"范围 %.0f–%.0f 的整数（pt）",
                                         kFBListPadMin, kFBListPadMax]
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = [NSString stringWithFormat:@"%.0f–%.0f", kFBListPadMin, kFBListPadMax];
        tf.keyboardType = UIKeyboardTypeNumberPad;
        tf.textAlignment = NSTextAlignmentCenter;
        tf.text = [NSString stringWithFormat:@"%.0f", FBListPad()];
        tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        NSString *raw = a.textFields.firstObject.text ?: @"";
        NSString *trimmed = [raw stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (trimmed.length == 0) return;

        CGFloat v = [trimmed doubleValue];
        if (v < kFBListPadMin) v = kFBListPadMin;
        if (v > kFBListPadMax) v = kFBListPadMax;

        FBSetListPad(round(v));
        [[NSUserDefaults standardUserDefaults] synchronize];
        FBApplyListPolishToAll();
        [self.tableView reloadData];
    }]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)fb_hostBarYOnToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBHostBarYOnKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBApplyHostToolbarToAll();
    [self.tableView reloadData];
}

- (void)fb_hostBarYChanged:(UISlider *)slider {
    FBSetHostBarOffset(round(slider.value));
    FBSettingCell *c = (FBSettingCell *)[self.tableView cellForRowAtIndexPath:
                                         [NSIndexPath indexPathForRow:7 inSection:kFBSecAppearance]];
    if ([c isKindOfClass:[FBSettingCell class]]) {
        c.valueLbl.text = [NSString stringWithFormat:@"%.0f", FBHostBarOffset()];
    }
    FBApplyHostToolbarToAll();
}

- (void)fb_hostBarYEnded:(UISlider *)slider {
    slider.value = round(slider.value);
    FBSetHostBarOffset(slider.value);
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBApplyHostToolbarToAll();
}

- (void)fb_hostBarToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBHostBarKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBApplyHostToolbarToAll();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ FBApplyHostToolbarToAll(); });
    [self.tableView reloadData];
}

- (void)fb_hostNavToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBHostNavKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    FBApplyHostNavToAll();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ FBApplyHostNavToAll(); });
    [self.tableView reloadData];
}

- (void)fb_shadowToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBShadowKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.tableView reloadData];
}

- (void)fb_globalToggled:(UISwitch *)sw {
    [[NSUserDefaults standardUserDefaults] setBool:sw.isOn forKey:FBGlobalKey];
    [[NSUserDefaults standardUserDefaults] synchronize];

    if (sw.isOn) {
        FBApplyGlobalTint();
    } else {
        UIColor *accent = FBAccentColor();
        for (UIWindow *w in UIApplication.sharedApplication.windows) {
            if (!w || w.hidden) continue;
            if (![w.tintColor isEqual:accent]) continue;
            w.tintColor = nil;
        }
    }
}

- (void)fb_presentSheet:(UIAlertController *)sheet anchor:(NSIndexPath *)ip {
    UITableViewCell *anchor = [self.tableView cellForRowAtIndexPath:ip];
    if (anchor) {
        sheet.popoverPresentationController.sourceView = anchor;
        sheet.popoverPresentationController.sourceRect = anchor.bounds;
        sheet.popoverPresentationController.permittedArrowDirections = 0;
    }
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];

    if (ip.section == kFBSecDisplay && ip.row == 2) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"图片显示方式"
                                                                  message:nil
                                                           preferredStyle:UIAlertControllerStyleActionSheet];
        NSArray *names = @[ @"填充（裁切铺满）", @"适应（完整显示）", @"拉伸（变形铺满）" ];
        for (NSInteger i = 0; i < 3; i++) {
            [a addAction:[UIAlertAction actionWithTitle:names[i]
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction *x) {
                [[NSUserDefaults standardUserDefaults] setInteger:i forKey:FBModeKey];
                [[NSUserDefaults standardUserDefaults] synchronize];
                FBNotifyChanged();
                [self.tableView reloadData];
            }]];
        }
        [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [self fb_presentSheet:a anchor:ip];
        return;
    }

    if (ip.section == kFBSecImage) {
        BOOL light = (ip.row == 0);
        UIAlertController *a = [UIAlertController alertControllerWithTitle:(light ? @"浅色背景图" : @"深色背景图")
                                                                  message:@"选择图片来源"
                                                           preferredStyle:UIAlertControllerStyleActionSheet];
        [a addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *x) {
            [self fb_pickImageForLight:light source:FBPickSourcePhotos];
        }]];
        [a addAction:[UIAlertAction actionWithTitle:@"从文件选择" style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *x) {
            [self fb_pickImageForLight:light source:FBPickSourceFiles];
        }]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:(light ? FBImage() : FBDarkImage())]) {
            [a addAction:[UIAlertAction actionWithTitle:@"移除当前图片" style:UIAlertActionStyleDestructive
                                                handler:^(UIAlertAction *x) {
                [[NSFileManager defaultManager] removeItemAtPath:(light ? FBImage() : FBDarkImage()) error:nil];
                FBInvalidateImageCache();
                gFBThumbCache = nil;
                FBNotifyChanged();
                [self.tableView reloadData];
            }]];
        }
        [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [self fb_presentSheet:a anchor:ip];
        return;
    }

    if (ip.section == kFBSecOther && ip.row == 0) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"恢复默认背景"
                                                                  message:@"会删掉两张背景图，并把透明度、显示方式恢复默认。主题色保留。"
                                                           preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [a addAction:[UIAlertAction actionWithTitle:@"恢复" style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *x) {
            NSFileManager *fm = [NSFileManager defaultManager];
            [fm removeItemAtPath:FBImage() error:nil];
            [fm removeItemAtPath:FBDarkImage() error:nil];
            NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
            [d removeObjectForKey:FBAlphaKey];
            [d removeObjectForKey:FBModeKey];
            [d synchronize];
            FBInvalidateImageCache();
            gFBThumbCache = nil;
            FBNotifyChanged();
            [self.tableView reloadData];
        }]];
        [self presentViewController:a animated:YES completion:nil];
        return;
    }

    if (ip.section == kFBSecOther && ip.row == 1) {
        NSString *realDir = FBDir();
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"图片存放路径"
                                                                  message:[NSString stringWithFormat:
                                         @"%@\n\n浅色图：background.png\n深色图：background-dark.png\n\n"
                                         @"放好图片后杀掉 Filza 重开即可。",
                                         FBDisplayPath(realDir)]
                                                           preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"拷贝真实路径" style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *x) {
            UIPasteboard.generalPasteboard.string = realDir;
        }]];
        [a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
    }
}

#pragma mark 选图落地

- (void)fb_pickImageForLight:(BOOL)light source:(FBPickSource)source {
    FBImagePickerHostController *host = [[FBImagePickerHostController alloc] init];
    self.pickerHost = host;
    __weak typeof(self) weakSelf = self;
    host.completionBlock = ^(UIImage *image) {
        __strong typeof(weakSelf) self = weakSelf;
        if (!self) return;
        self.pickerHost = nil;
        if (image) [self fb_handlePickedImage:image light:light];
    };
    [host presentFrom:self source:source];
}

- (void)fb_handlePickedImage:(UIImage *)image light:(BOOL)light {
    UIImage *compressed = FBCompressImage(image);
    BOOL ok = FBWriteImage(compressed, light ? FBImage() : FBDarkImage());

    if (ok) {
        FBInvalidateImageCache();
        gFBThumbCache = nil;
        FBNotifyChanged();
        [self.tableView reloadData];
    }

    UIAlertController *a = [UIAlertController alertControllerWithTitle:(ok ? @"已设置" : @"保存失败")
                                                              message:(ok ? (light ? @"浅色背景图已更新" : @"深色背景图已更新")
                                                                          : @"写不进目录，请检查权限")
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

@end

#pragma mark - 底部区域视图探测

#pragma mark - 目录与写入

static void FBEnsureDir(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *dir = FBDir();
    if (![fm fileExistsAtPath:dir]) {
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    }
    chmod([dir fileSystemRepresentation], 0777);
}

static BOOL FBWriteImage(UIImage *image, NSString *path) {
    if (!image || path.length == 0) return NO;
    NSData *data = UIImagePNGRepresentation(image);
    if (!data) return NO;
    FBEnsureDir();
    BOOL ok = [data writeToFile:path options:NSDataWritingAtomic error:nil];
    if (ok) chmod([path fileSystemRepresentation], 0644);
    return ok;
}

static UIImage *FBCompressImage(UIImage *image) {
    if (!image) return nil;
    const CGFloat maxSide = 3000.0;
    CGSize size = image.size;
    CGFloat side = MAX(size.width, size.height);
    if (side <= maxSide || side <= 0) return image;

    CGFloat s = maxSide / side;
    CGSize newSize = CGSizeMake(floor(size.width * s), floor(size.height * s));
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 1.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return result ?: image;
}

#pragma mark - Hook

static void (*orig_viewDidLoad)(UIViewController *, SEL);
static void (*orig_viewWillAppear)(UIViewController *, SEL, BOOL);
static void (*orig_viewDidAppear)(UIViewController *, SEL, BOOL);
static void (*orig_traitDidChange)(UIViewController *, SEL, UITraitCollection *);
static UIColor *(*orig_colorNamed)(Class, SEL, NSString *);

static BOOL FBTitleLooksLikeSettings(UIViewController *vc) {
    NSString *cn = [NSStringFromClass([vc class]) lowercaseString] ?: @"";
    if ([cn containsString:@"setting"] || [cn containsString:@"pref"]) return YES;

    NSString *title = vc.navigationItem.title ?: vc.title ?: @"";
    if (title.length == 0) return NO;
    return ([title rangeOfString:@"设置"].location != NSNotFound ||
            [title rangeOfString:@"偏好"].location != NSNotFound ||
            [title.lowercaseString containsString:@"settings"] ||
            [title.lowercaseString containsString:@"preferences"]);
}

static BOOL FBIsOurItem(UIBarButtonItem *item) {
    return item && item.action == @selector(fb_openBackgroundSettings);
}

static void FBEnsureSettingsEntry(UIViewController *vc) {
    if ([vc isKindOfClass:NSClassFromString(@"FBSettingsController")]) return;
    if (!vc.navigationItem) return;
    if (!FBTitleLooksLikeSettings(vc)) return;

    UIBarButtonItem *cur = vc.navigationItem.rightBarButtonItem;
    if (FBIsOurItem(cur)) return;

    UIBarButtonItem *ours = [[UIBarButtonItem alloc] initWithImage:FBEntryGlyph()
                                                            style:UIBarButtonItemStylePlain
                                                           target:vc
                                                           action:@selector(fb_openBackgroundSettings)];
    ours.accessibilityLabel = @"背景设置";
    ours.tintColor = FBAccentColor();

    if (cur && cur.customView == nil && cur.image == nil && cur.title.length == 0) {
        vc.navigationItem.rightBarButtonItem = ours;
    } else if (cur) {
        vc.navigationItem.rightBarButtonItems = @[ cur, ours ];
    } else {
        vc.navigationItem.rightBarButtonItem = ours;
    }
}

static void fb_viewDidLoad(UIViewController *self, SEL _cmd) {
    orig_viewDidLoad(self, _cmd);
    if (!FBInFilza()) return;
    if (!FBIsFilzaController(self)) return;

    static dispatch_once_t once;
    dispatch_once(&once, ^{
        FBEnsureDir();
        FBInstallObservers();
    });

    FBAddBackgroundToView(self.view);
}

static void fb_viewWillAppear(UIViewController *self, SEL _cmd, BOOL animated) {
    orig_viewWillAppear(self, _cmd, animated);
    if (!FBInFilza()) return;
    if (!FBIsFilzaController(self)) return;

    FBEnsureSettingsEntry(self);
    FBAddBackgroundToView(self.view);
    FBApplyListPolish(self);
    FBApplyHostNavBar(self.navigationController.navigationBar);
    NSMutableArray<UIToolbar *> *bars0 = [NSMutableArray array];
    for (UIWindow *w in UIApplication.sharedApplication.windows) FBCollectToolbars(w, 0, bars0);
    for (UIToolbar *b in bars0) FBApplyHostToolbar(b);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        FBApplyHostToolbar(FBFindToolbarForVC(self));
    });
}

static void fb_viewDidAppear(UIViewController *self, SEL _cmd, BOOL animated) {
    orig_viewDidAppear(self, _cmd, animated);
    if (!FBInFilza()) return;
    if (!FBIsFilzaController(self)) return;
    FBAddBackgroundToView(self.view);
    FBApplyListPolish(self);
}

static void fb_traitDidChange(UIViewController *self, SEL _cmd, UITraitCollection *previous) {
    orig_traitDidChange(self, _cmd, previous);
    if (!FBInFilza()) return;
    if (previous.userInterfaceStyle == self.traitCollection.userInterfaceStyle) return;
    FBInvalidateImageCache();
    FBRefreshAllWindows();
}

static UIColor *fb_colorNamed(Class self, SEL _cmd, NSString *name) {
    if (FBGlobalTintOn() && [name isEqualToString:@"AccentColor"]) {
        return FBAccentColor();
    }
    return orig_colorNamed(self, _cmd, name);
}

static void fb_openBackgroundSettings(UIViewController *self, SEL _cmd) {
    FBSettingsController *vc = [[FBSettingsController alloc] initWithStyle:UITableViewStyleInsetGrouped];
    vc.title = @"背景设置";
    vc.hidesBottomBarWhenPushed = YES;

    UINavigationController *nav = self.navigationController;
    if (nav) {
        [nav pushViewController:vc animated:YES];
        nav.navigationBar.tintColor = FBAccentColor();
    } else {
        UINavigationController *newNav = [[UINavigationController alloc] initWithRootViewController:vc];
        newNav.navigationBar.tintColor = FBAccentColor();
        [self presentViewController:newNav animated:YES completion:nil];
    }
}

#pragma mark - 实时对账

static dispatch_source_t gFBRealtimeTimer = nil;

static void FBStartRealtimeTimer(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gFBRealtimeTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,
                                                  dispatch_get_main_queue());
        dispatch_source_set_timer(gFBRealtimeTimer,
                                  dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC),
                                  NSEC_PER_SEC,
                                  100 * NSEC_PER_MSEC);
        dispatch_source_set_event_handler(gFBRealtimeTimer, ^{
            if (!FBInFilza()) return;
            FBApplyHostNavToAll();
            FBApplyHostToolbarToAll();
            FBApplyListPolishToAll();
        });
        dispatch_resume(gFBRealtimeTimer);
    });
}

#pragma mark - 初始化

__attribute__((constructor)) static void FBInit(void) {
    if (!FBInFilza()) return;

    Class vcCls = objc_getClass("UIViewController");
    if (vcCls) {
        MSHookMessageEx(vcCls, @selector(viewDidLoad), (IMP)fb_viewDidLoad, (IMP *)&orig_viewDidLoad);
        MSHookMessageEx(vcCls, @selector(viewWillAppear:), (IMP)fb_viewWillAppear, (IMP *)&orig_viewWillAppear);
        MSHookMessageEx(vcCls, @selector(viewDidAppear:), (IMP)fb_viewDidAppear, (IMP *)&orig_viewDidAppear);
        MSHookMessageEx(vcCls, @selector(traitCollectionDidChange:), (IMP)fb_traitDidChange, (IMP *)&orig_traitDidChange);
        class_addMethod(vcCls, @selector(fb_openBackgroundSettings), (IMP)fb_openBackgroundSettings, "v@:");
    }

    Class tbCls = objc_getClass("UIToolbar");
    if (tbCls) {
        MSHookMessageEx(tbCls, @selector(setBackgroundImage:forToolbarPosition:barMetrics:),
                        (IMP)fb_setToolbarBg, (IMP *)&orig_setToolbarBg);
        MSHookMessageEx(tbCls, @selector(setShadowImage:forToolbarPosition:),
                        (IMP)fb_setToolbarShadow, (IMP *)&orig_setToolbarShadow);
    }

    Class uiColorMeta = object_getClass(objc_getClass("UIColor"));
    if (uiColorMeta) {
        MSHookMessageEx(uiColorMeta, @selector(colorNamed:), (IMP)fb_colorNamed, (IMP *)&orig_colorNamed);
    }

    FBEnsureDir();
    FBInstallObservers();
    FBApplyGlobalTint();
    FBStartRealtimeTimer();

    for (int i = 0; i < 3; i++) {
        int delayMs = 300 + i * 500;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayMs * NSEC_PER_MSEC)),
                       dispatch_get_main_queue(), ^{
            FBApplyGlobalTint();
            FBRefreshAllWindows();
        });
    }
}

